import React from "react";
import PropTypes from "prop-types";
// core components
import { makeStyles } from "@material-ui/core/styles";
import GridContainer from "components/Grid/GridContainer.js";
import Button from "components/CustomButtons/Button.js";
import Datetime from "react-datetime";
import GridItem from "components/Grid/GridItem.js";
import CustomInput from "components/CustomInput/CustomInput.js";
import InputAdornment from "@material-ui/core/InputAdornment";
import TextField from '@material-ui/core/TextField';
import Autocomplete from '@material-ui/lab/Autocomplete';
import Icon from "@material-ui/core/Icon";
import styles from "assets/jss/material-dashboard-pro-react/views/validationFormsStyle.js";
import withStyles from "@material-ui/core/styles/withStyles";
import Card from "components/Card/Card.js";
import CardHeader from "components/Card/CardHeader.js";
import SimpleBackdrop from '../../utils/general';
import _ from 'lodash';
import CardIcon from "components/Card/CardIcon.js";
import cogoToast from "cogo-toast";
import FlightTakeoff from "@material-ui/icons/FlightTakeoff";
import ReactTable from "react-table";
import CardBody from "components/Card/CardBody.js";
import moment from 'moment';
import api from '../../utils/apiClient';
import FormControl from "@material-ui/core/FormControl";
import { apiBase } from '../../utils/config';
import { CommonConfig } from "utils/constant.js";
import InputLabel from "@material-ui/core/InputLabel";
import Select from "@material-ui/core/Select";
import MenuItem from "@material-ui/core/MenuItem";

const useStyles = () => makeStyles(styles);
const classes = useStyles();

class ShipmentCustom extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            Steps: [
                { stepName: "Customer Details", stepId: "customerdetails", classname: "active" },
                { stepName: "Package", stepId: "package", classname: "inactive" },
                { stepName: "Commercial Inv.", stepId: "commercialinvoice", classname: "inactive" },
                { stepName: "Accounts", stepId: "accounts", classname: "inactive" },
                { stepName: "Tracking", stepId: "tracking", classname: "inactive" },
                // { stepName: "Insurance & Claim", stepComponent: Step6, stepId: "Insurance&Claim" },
                { stepName: "Documentation", stepId: "documentations", classname: "inactive" }
            ],
            shipmentTypeList: [],
            ManagedBy: "",
            managedByList: [],
            TrackingNumber: "",
            ServiceType: "",
            SubServiceType: "",
            CreatedBy: "",
            ShipmentDate: "",
            ShipmentType: "",
            notes: [],
            ServiceList: [],
            SubServiceList: [],
            Subservicename: true,
            subServiceName: [],
            ServiceName: "",
            SubServiceName: "",

            CountryList: [],
            FromAddress: {},
            ToAddress: {},
            selectedFromCountry: {},
            selectedToCountry: {},
            YesNo: [
                { value: true, label: "Yes" },
                { value: false, label: "No" }
            ],
            FromMovingBack: false,
            FromEligibleForTR: false,
            FromOriginalPassortAvailable: false,
            fromCityAutoComplete: false,
            fromStateAutoComplete: false,
            fromGoogleAPICityList: [],
            fromStateList: [],

            toCityAutoComplete: false,
            toStateAutoComplete: false,
            toGoogleAPICityList: [],
            toStateList: [],

            fromState: "",
            fromCity: "",
            toState: "",
            toCity: "",

            PackageList: [],
            PackageType: "",
            packageType: [
                { value: 1, label: 'Boxes' },
                { value: 2, label: 'Documents' },
                { value: 3, label: 'Furniture' },
                { value: 4, label: 'TV' },
                { value: 5, label: 'Auto' },
            ],
            packedBy: [
                { value: "Owner", label: 'Owner' },
                { value: "Mover", label: 'Mover' }
            ],
            optionYes: [
                { value: "Yes", label: "Yes" },
                { value: "No", label: "No" }
            ],
            TotalPackages: 0,

            commercialList: [],


            PaymentList: [],
            paymentReceived: [],
            paymentIssued: [],
            paymentMethod: [],
            ServiceDescriptionList: [],
            PaymentTypeList: [],
            VendorList: [],
            PaymentMethodType: [
                { value: "Bank", label: "Bank" },
                { value: "Credit Card", label: "Credit Card" },
                // {value:"AMERICAN EXPRESS",label:"AMERICAN EXPRESS"},
                // {value:"RUPAY",label:"RUPAY"},
            ],
            yesNo: [
                { value: "Yes", label: "Yes" },
                { value: "No", label: "No" },
                { value: "N/A", label: "N/A" }
            ],

            trackingNumberList: [],
            TrackingServiceList: [],
            activeInactive: [
                { value: "Active", label: "Active" },
                { value: "Inactive", label: "Inactive" }
            ],
            Attachments: [],
            Loading: false,
            objAttachment: {
                Index: 0,
                FileName: '',
                Status: "Active",
                DocumentCreatedOn: moment().format(CommonConfig.dateFormat.dateOnly),
                DocumentCreatedBy: CommonConfig.loggedInUserData().Name,
            },
            Attachments: [],
            objAttachment: {
                Index: 0,
                FileName: '',
                Status: "Active",
                DocumentCreatedOn: moment().format(CommonConfig.dateFormat.dateOnly),
                DocumentCreatedBy: CommonConfig.loggedInUserData().Name,
            },
        }
    }

    async componentDidMount() {
        await this.getCountry();
        this.showHide();
        await this.getShipmentType();
        await this.getManagedBy();
        await this.getService();
        await this.getShipmentInfo();
        await this.getAddressDetails();
        await this.getPackageDetail();
        await this.getCommercialInvoiceDetail();
        await this.getAccountDetail();
        await this.getServiceDescription();
        await this.getpaymentType();
        await this.getVendorName();
        await this.getnotesByID();
        await this.trackingService();
        await this.setState({ Attachments: [this.state.objAttachment] });
        await this.handleAddNotesRow();
        await this.addnewRowTrackingNumber();
        // await this.addnewRowInvoice();
        // await this.addRowPaymentReceived();
        // await this.addRowPaymentIssued();
        // await this.addRowPaymentMethod();
    }

    showHide() {
        document.getElementById("customerdetails").style.display = "block";
        document.getElementById("package").style.display = "none";
        document.getElementById("commercialinvoice").style.display = "none";
        document.getElementById("accounts").style.display = "none";
        document.getElementById("tracking").style.display = "none";
        document.getElementById("documentations").style.display = "none";
    }

    getManagedBy() {
        try {
            api.get("scheduleshipment/getShipmentManagedBy").then(result => {
                this.setState({ managedByList: result.data })
            }).catch(err => {
                console.log(err);
            })
        }
        catch (err) {
            console.log("error", err);
        }

    }

    getService() {
        try {
            api.get("userManagement/getServiceName").then(result => {
                if (result.success) {
                    this.setState({ ServiceList: result.data.ServiceName, subServiceName: result.data.SubServiceName });
                }
            }).catch(err => {
                console.log(err);
            })
        }
        catch (err) {
            console.log("error", err);
        }
    }

    getShipmentType() {
        try {
            let data = {
                stringMapType: "SHIPMENTTYPE"
            }

            api.post("stringMap/getstringMap", data).then(result => {
                this.setState({ shipmentTypeList: result.data })
            }).catch(err => {
                console.log(err);
            })
        }
        catch (err) {
            console.log("error", err);
        }
    }

    getShipmentInfo() {
        try {
            let data = {
                ShippingID: this.props.location.state.ShipppingID
            }
            api.post("scheduleshipment/getShipmentInfo", data).then(res => {
                if (res.success) {
                    var shipmentType = {
                        value: res.data[0].ShipmentType,
                        label: res.data[0].ShipmentType
                    }
                    var managedBy = {
                        value: res.data[0].ManagedBy,
                        label: res.data[0].ManagedByName
                    }

                    var serviceName = {
                        value: res.data[0].ServiceName,
                        label: res.data[0].ServiceName
                    }

                    var subServiceName = {
                        value: res.data[0].SubServiceName,
                        label: res.data[0].SubServiceName
                    }
                    this.setState({
                        ManagedBy: managedBy,
                        TrackingNumber: res.data[0].TrackingNumber,
                        CreatedBy: res.data[0].CreatedBy,
                        ServiceName: serviceName,
                        SubServiceName: subServiceName,
                        Subservicename: false,
                        ShipmentDate: res.data[0].ShipmentDate,
                        ShipmentType: shipmentType
                    });
                }

            })
        }
        catch (error) {
            console.log("error...", error);
        }
    }

    change(event, type) {
        console.log("change called..");
    }

    getnotesByID() {
        try {
            let data = {
                ShippingID: this.props.location.state.ShipppingID
            }
            api.post("scheduleshipment/getShipmentNotesByID", data).then(result => {
                var i = 0;
                result.data.map(Obj => {
                    Obj.Index = i;
                    i++;
                    return Obj;
                })
                result.data.map(Obj => {
                    Obj.disabled = i;
                    i++;
                    return Obj;
                })
                this.setState({ notes: result.data });
                this.handleAddNotesRow();
            }).catch(err => {
                console.log("error......", err);
            })
        }
        catch (err) {
            console.log("error", err);
        }
    }

    handleAddNotesRow = () => {
        var addnotes = this.state.notes.filter(x => (x.Status === "Active" && (x.NoteText === null || x.NoteText === "")))
        if (addnotes.length === 0) {
            var todayDate = new Date();
            const note = {
                NoteText: "",
                NoteType: null,
                NoteTitle: null,
                Status: "Active",
                AttachmentID: null,
                AttachmentType: null,
                AttachmentName: null,
                CreatedOn: moment(todayDate).format(CommonConfig.dateFormat.dateTime),
                disabled: false,
                closebutton: true,
                CreatedBy: CommonConfig.loggedInUserData().PersonID,
                NoteID: null,
                CreatedByNote: CommonConfig.loggedInUserData().Name,
                AddedBy: CommonConfig.loggedInUserData().Name,
                Index: this.state.notes.length + 1
            }
            this.setState({ notesDisabled: false, notes: [...this.state.notes, note] });
        } else {
            cogoToast.error("Please fill above note first");
        }


    }

    handleChangeNotes = (event, idx) => {
        const { value } = event.target;
        const notes = [...this.state.notes];
        var noteIndex = notes.findIndex(x => x.Index === idx);
        if (noteIndex !== -1) {
            notes[noteIndex]["NoteText"] = value;
            if (notes[noteIndex]["NoteText"] === null || notes[noteIndex]["NoteText"] === "") {
                this.setState({ noteErr: true });
            } else {
                this.setState({ noteErr: false })
            }
        }
        this.setState({ notes: notes });
    }

    handleNotesRemoveRow = (Index) => {
        const removeNotes = [...this.state.notes]
        var noteIndex = this.state.notes.findIndex(x => x.Index === Index);
        if (noteIndex !== -1) {
            removeNotes[noteIndex]["Status"] = "Inactive";
            removeNotes[noteIndex]["AttachmentStatus"] = "Inactive";
            this.setState({ notes: removeNotes });
        }
    }

    selectChange = (event, value, type) => {
        if (type === "ServiceType") {
            var service = this.state.subServiceName;
            var finalService = service.filter(x => (x.MainServiceName === value.value && x.ServiceType === this.state.ShipmentType.value));
            this.setState({ Subservicename: false, SubServiceList: finalService, ServiceName: value, SubServiceName: "" });
        }
        else if (type === "SubServiceType") {
            this.setState({ SubServiceName: value });
        }
        else if (type === "ManagedBy") {
            this.setState({ ManagedBy: value });
        }
        else if (type === "ShipmentType") {
            var service = this.state.subServiceName;
            var finalService = service.filter(x => (x.ServiceType === value.value && x.MainServiceName === this.state.ServiceName.value));
            this.setState({ ShipmentType: value, SubServiceList: finalService, SubServiceName: "" });
        }
    }

    viewNotes = () => {
        return this.state.notes.filter(x => x.Status === 'Active').map((notes, idx) => {
            return (
                <tr>
                    <td>{moment(notes.CreatedOn).format(CommonConfig.dateFormat.dateTime)}</td>
                    <td style={{ maxWidth: 600, margin: 0, height: 68, width: 600 }}>
                        {notes.disabled ?

                            <p id="noteText" dangerouslySetInnerHTML={{ __html: notes.NoteText.replace(/\r?\n/g, '<br />') }}></p>
                            :
                            <div className="table-textarea">
                                <textarea name="NoteText" style={{ width: 582, margin: 0, height: 68 }} disabled={notes.disabled} value={notes.NoteText} onChange={(event) => this.handleChangeNotes(event, notes.Index)}></textarea>
                            </div>
                        }
                    </td>

                    {notes.disabled && (notes.AttachmentPath === null || notes.AttachmentPath === "" || notes.AttachmentPath === undefined) ?
                        (<td></td>)
                        :
                        notes.disabled && notes.AttachmentPath ?
                            (<td><a target="_blank" className="normal-btn" href={apiBase + notes.AttachmentPath}>View Image</a></td>)
                            :
                            (<td>
                                <div className="custom-file-browse">
                                    <span>Choose File</span>
                                    <input type="file" name="selectedfile" id="file" style={{ width: 140, border: 0 }} onChange={(event) => this.handleFiles(event, notes.Index)} />
                                </div>
                                <br /><p>{notes.AttachmentName}</p>
                            </td>)
                    }
                    <td>{notes.CreatedByNote}</td>
                    <td>
                        <div className="pck-subbtn">
                            {/* {this.state.DeleteAccess === 1? */}
                            <Button justIcon color="danger" className="Plus-btn " onClick={() => this.handleNotesRemoveRow(notes.Index)} disabled={this.state.notesDisabled}>
                                <i className={"fas fa-minus"} />
                            </Button>
                            {this.state.notes.filter(x => x.Status === "Active").length === idx + 1 ?
                                <Button justIcon color="facebook" onClick={() => this.handleAddNotesRow()} className="Plus-btn ">
                                    <i className={"fas fa-plus"} />
                                </Button>
                                : null
                            }
                        </div>
                        {/* this.handleAddNotesRow */}
                        {/* ):(null)
                } */}
                    </td>
                </tr>)

        });
    }

    navigateChange = (key) => {
        let stepsList = this.state.Steps;
        let activeIndex = stepsList.findIndex(x => x.classname === "active");
        if (key !== activeIndex) {
            stepsList[key]["classname"] = "active";
            stepsList[activeIndex]["classname"] = "inactive";
            this.setState({ Steps: stepsList });
            let divID = stepsList[key]["stepId"];
            let activeDiv = stepsList[activeIndex]["stepId"]
            document.getElementById(divID).style.display = "block";
            document.getElementById(activeDiv).style.display = "none";
        }
    }


    toStates(countryData) {
        try {

            let data = {
                countryId: countryData.value
            }

            api.post('location/getStateList', data).then(res => {
                if (res.success) {
                    if (res.data.length) {
                        var ToState = {
                            value: this.state.toState,
                            label: this.state.toState
                        }


                        this.setState({
                            toStateList: res.data,
                            toState: ToState,
                            toStateAutoComplete: res.data.length ? true : false
                        });
                    }
                    else {
                        this.setState({
                            toStateList: res.data,
                            toStateAutoComplete: res.data.length ? true : false
                        });

                    }

                }
            }).catch(err => {
                console.log("err...", err);
                cogoToast.error("Something Went Wrong");
            });
        } catch (error) {

        }

    }

    getStates(countryData) {
        try {

            let data = {
                countryId: countryData.value
            }

            api.post('location/getStateList', data).then(res => {
                if (res.success) {

                    this.showLoader();
                    if (res.data.length) {
                        var FromState = {
                            value: this.state.fromState,
                            label: this.state.fromState
                        }

                        this.setState({
                            fromStateList: res.data,
                            fromState: FromState,
                            fromStateAutoComplete: res.data.length ? true : false,
                        });
                    }
                    else {
                        this.setState({
                            fromStateList: res.data,
                            fromStateAutoComplete: res.data.length ? true : false,
                        });

                    }
                    this.hideLoader();
                }
            }).catch(err => {
                this.hideLoader();
                console.log("err...", err);
                cogoToast.error("Something Went Wrong");
            });
        } catch (error) {
            this.hideLoader();
        }

    }

    showLoader() {
        this.setState({ Loading: true });
    }

    hideLoader() {
        this.setState({ Loading: false });
    }

    getAddressDetails() {
        try {
            let data = {
                ShippingID: this.props.location.state.ShipppingID
            }
            api.post("scheduleshipment/getShipmentByID", data).then(res => {
                if (res.success) {
                    if (res.data.length) {
                        let fromRes = res.data.filter(x => x.EntityType === "FromAddress");
                        let toRes = res.data.filter(x => x.EntityType === "ToAddress");
                        var fromCountry = this.state.CountryList.filter(x => x.CountryID === fromRes[0].CountryID);
                        var toCountry = this.state.CountryList.filter(x => x.CountryID === toRes[0].CountryID);
                        var selectedFromCountry = {
                            value: fromCountry[0].CountryID,
                            label: fromCountry[0].CountryName
                        }
                        var selectedToCountry = {
                            value: toCountry[0].CountryID,
                            label: toCountry[0].CountryName
                        }
                        var fromMovingBack = {
                            value: fromRes[0].MovingBack.data[0] === 0 ? false : true,
                            label: fromRes[0].MovingBack.data[0] === 0 ? "No" : "Yes"
                        }
                        var fromEligibleForTr = {
                            value: fromRes[0].EligibleForTR.data[0] === 0 ? false : true,
                            label: fromRes[0].EligibleForTR.data[0] === 0 ? "No" : "Yes"
                        }
                        var fromOriginalPassortAvailable = {
                            value: fromRes[0].OriginalPassportAvailable.data[0] === 0 ? false : true,
                            label: fromRes[0].OriginalPassportAvailable.data[0] === 0 ? "No" : "Yes"
                        }
                        this.setState({
                            FromAddress: fromRes[0],
                            ToAddress: toRes[0],
                            fromState: fromRes[0].State,
                            fromCity: fromRes[0].City,
                            toState: toRes[0].State,
                            toCity: toRes[0].City,
                            // ShipmentType : fromRes[0].ShipmentType,
                            FromMovingBack: fromMovingBack,
                            FromEligibleForTR: fromEligibleForTr,
                            FromOriginalPassortAvailable: fromOriginalPassortAvailable,
                            selectedFromCountry: selectedFromCountry,
                            selectedToCountry: selectedToCountry,
                        });
                        this.getStates(selectedFromCountry);
                        this.toStates(selectedToCountry);
                        // this.senderZipChange(fromRes[0].ZipCode);
                        // this.recipientZipChange(toRes[0].ZipCode);
                    }
                }
            }).catch(err => {
                console.log(err);
            })
        }
        catch (err) {
            console.log("error...", err);
        }
    }

    getCountry() {
        try {
            api.get('location/getCountryList').then(res => {
                if (res.success) {
                    var Country = res.data;
                    this.setState({ CountryList: Country });
                }
            }).catch(err => {
                console.log("err..", err);
                // cogoToast.error("Something Went Wrong");
            });
        } catch (error) {

        }
    }

    selectChangeTab1 = (event, value, type) => {
        if (type === "FromCountry") {
            this.setState({ selectedFromCountry: value, fromCity: "", fromState: "" });
            this.getStates(value);
        }
        else if (type === "ToCountry") {
            this.setState({ selectedToCountry: value, toCity: "", toState: "" });
            this.toStates(value);
        }
        else if (type === "MovingBack") {
            this.setState({ FromMovingBack: value });
        }
        else if (type === "PassportAvailable") {
            this.setState({ FromOriginalPassortAvailable: value });
        }
        else if (type === "EligibleTR") {
            this.setState({ FromEligibleForTR: value });
        }
    }

    handleChangeFrom = (event, type) => {
        if (type === "companyname") {
            let fromAddress = this.state.FromAddress;
            fromAddress.CompanyName = event.target.value;
            this.setState({ FromAddress: fromAddress });
        }
        else if (type === "contactname") {
            let fromAddress = this.state.FromAddress;
            fromAddress.ContactName = event.target.value;
            this.setState({ FromAddress: fromAddress });
        }
        else if (type === "address1") {
            let fromAddress = this.state.FromAddress;
            fromAddress.AddressLine1 = event.target.value;
            this.setState({ FromAddress: fromAddress });
        }
        else if (type === "address2") {
            let fromAddress = this.state.FromAddress;
            fromAddress.AddressLine2 = event.target.value;
            this.setState({ FromAddress: fromAddress });
        }
        else if (type === "address3") {
            let fromAddress = this.state.FromAddress;
            fromAddress.AddressLine3 = event.target.value;
            this.setState({ FromAddress: fromAddress });
        }
        else if (type === "zip") {
            let fromAddress = this.state.FromAddress;
            fromAddress.ZipCode = event.target.value;
            this.setState({ FromAddress: fromAddress });
        }
        else if (type === "phone1") {
            let fromAddress = this.state.FromAddress;
            fromAddress.Phone1 = event.target.value;
            this.setState({ FromAddress: fromAddress });
        }
        else if (type === "phone2") {
            let fromAddress = this.state.FromAddress;
            fromAddress.Phone2 = event.target.value;
            this.setState({ FromAddress: fromAddress });
        }
        else if (type === "email") {
            let fromAddress = this.state.FromAddress;
            fromAddress.Email = event.target.value;
            this.setState({ FromAddress: fromAddress });
        }
    }

    handleChangeTo = (event, type) => {
        if (type === "companyname") {
            let toAddress = this.state.ToAddress;
            toAddress.CompanyName = event.target.value;
            this.setState({ ToAddress: toAddress });
        }
        else if (type === "contactname") {
            let toAddress = this.state.ToAddress;
            toAddress.ContactName = event.target.value;
            this.setState({ ToAddress: toAddress });
        }
        else if (type === "address1") {
            let toAddress = this.state.ToAddress;
            toAddress.AddressLine1 = event.target.value;
            this.setState({ ToAddress: toAddress });
        }
        else if (type === "address2") {
            let toAddress = this.state.ToAddress;
            toAddress.AddressLine2 = event.target.value;
            this.setState({ ToAddress: toAddress });
        }
        else if (type === "address3") {
            let toAddress = this.state.ToAddress;
            toAddress.AddressLine3 = event.target.value;
            this.setState({ ToAddress: toAddress });
        }
        else if (type === "zip") {
            let toAddress = this.state.ToAddress;
            toAddress.ZipCode = event.target.value;
            this.setState({ ToAddress: toAddress });
        }
        else if (type === "phone1") {
            let toAddress = this.state.ToAddress;
            toAddress.Phone1 = event.target.value;
            this.setState({ ToAddress: toAddress });
        }
        else if (type === "phone2") {
            let toAddress = this.state.ToAddress;
            toAddress.Phone2 = event.target.value;
            this.setState({ ToAddress: toAddress });
        }
        else if (type === "email") {
            let toAddress = this.state.ToAddress;
            toAddress.Email = event.target.value;
            this.setState({ ToAddress: toAddress });
        }
    }

    senderZipChange = (zip) => {
        if (zip.length) {
            fetch(CommonConfig.zipCodeAPIKey(zip))
                .then(result => result.json())
                .then(data => {
                    if (data["status"] === "OK") {

                        if (data["results"][0] && data["results"][0].hasOwnProperty('postcode_localities')) {
                            var FinalCity = [];

                            var countryShortName = "";

                            countryShortName = _.filter(data["results"][0]["address_components"], function (data) {
                                return data.types[0] === "country"
                            })[0].long_name;

                            var CityData = data["results"][0]["postcode_localities"];
                            _.forEach(CityData, function (value, key) {
                                FinalCity.push({
                                    "City_code": value,
                                    "Name": value
                                });
                            });

                            var state = _.filter(data["results"][0]["address_components"], function (data) {
                                return data.types[0] === "administrative_area_level_1"
                            })[0].long_name;


                            var SelectedCity = { value: FinalCity[0].City_code, label: FinalCity[0].Name }

                            var SelectedState = { value: state, label: state }

                            if (countryShortName === this.state.selectedFromCountry.label) {

                                this.setState({
                                    fromCityAutoComplete: FinalCity.length ? true : false,
                                    fromStateAutoComplete: this.state.fromStateList.length ? true : false,
                                    fromGoogleAPICityList: FinalCity,
                                    fromState: this.state.fromStateList.length ? SelectedState : state,
                                    fromCity: SelectedCity
                                })
                            } else {
                                this.setState({
                                    fromCityAutoComplete: false,
                                    fromStateAutoComplete: this.state.fromStateList.length ? true : false,
                                    fromGoogleAPICityList: [],
                                    fromState: "",
                                    fromCity: ""
                                })
                            }

                        } else if (data["results"][0]) {

                            var FinalCity = [];
                            var city = "";
                            var countryShortName = "";

                            countryShortName = _.filter(data["results"][0]["address_components"], function (data) {
                                return data.types[0] === "country"
                            })[0].long_name;

                            if (city == "" && (_.filter(data["results"][0]["address_components"], function (data) { return data.types[0] === "locality" })).length > 0) {
                                city = _.filter(data["results"][0]["address_components"], function (data) {
                                    return data.types[0] === "locality"
                                })[0].short_name;

                            } else if (city == "" && (_.filter(data["results"][0]["address_components"], function (data) { return data.types[0] === "administrative_area_level_3" })).length > 0) {
                                city = _.filter(data["results"][0]["address_components"], function (data) {
                                    return data.types[0] === "administrative_area_level_3"
                                })[0].short_name;

                            } else if (city == "" && (_.filter(data["results"][0]["address_components"], function (data) { return data.types[0] === "political" })).length > 0) {
                                city = _.filter(data["results"][0]["address_components"], function (data) {
                                    return data.types[0] === "political"
                                })[0].short_name;

                            } else if (city == "" && (_.filter(data["results"][0]["address_components"], function (data) { return data.types[0] === "neighborhood" })).length > 0) {
                                city = _.filter(data["results"][0]["address_components"], function (data) {
                                    return data.types[0] === "neighborhood"
                                })[0].short_name;

                            } else if (city == "" && (_.filter(data["results"][0]["address_components"], function (data) { return data.types[0] === "administrative_area_level_2" })).length > 0) {
                                city = _.filter(data["results"][0]["address_components"], function (data) {
                                    return data.types[0] === "administrative_area_level_2"
                                })[0].long_name;

                            } else if (city == "" && (_.filter(data["results"][0]["address_components"], function (data) { return data.types[0] === "administrative_area_level_1" })).length > 0) {
                                city = _.filter(data["results"][0]["address_components"], function (data) {
                                    return data.types[0] === "administrative_area_level_1"
                                })[0].long_name;

                            } else if (city == "") {
                                city = ""
                            }

                            var state = _.filter(data["results"][0]["address_components"], function (data) {
                                return data.types[0] === "administrative_area_level_1"
                            })[0].long_name;


                            FinalCity.push({
                                "City_code": city,
                                "Name": city
                            });

                            var SelectedCity = { value: FinalCity[0].City_code, label: FinalCity[0].Name }

                            var SelectedState = { value: state, label: state }

                            if (countryShortName === this.state.selectedFromCountry.label) {
                                this.setState({
                                    fromCityAutoComplete: FinalCity.length ? true : false,
                                    fromStateAutoComplete: this.state.fromStateList.length ? true : false,
                                    fromGoogleAPICityList: FinalCity,
                                    fromState: this.state.fromStateList.length ? SelectedState : state,
                                    fromCity: SelectedCity
                                })
                            } else {
                                this.setState({
                                    fromCityAutoComplete: false,
                                    fromStateAutoComplete: this.state.fromStateList.length ? true : false,
                                    fromGoogleAPICityList: [],
                                    fromState: "",
                                    fromCity: ""
                                })
                            }
                        }
                    }
                    else {
                        this.setState({
                            fromCityAutoComplete: false,
                            fromStateAutoComplete: this.state.fromStateList.length ? true : false,
                            fromGoogleAPICityList: [],
                            fromState: "",
                            fromCity: ""
                        })
                    }

                });
        }

    }

    recipientZipChange = (zip) => {
        if (zip.length) {
            fetch(CommonConfig.zipCodeAPIKey(zip))
                .then(result => result.json())
                .then(data => {
                    if (data["status"] === "OK") {

                        if (data["results"][0] && data["results"][0].hasOwnProperty('postcode_localities')) {
                            var FinalCity = [];

                            var countryShortName = "";

                            countryShortName = _.filter(data["results"][0]["address_components"], function (data) {
                                return data.types[0] === "country"
                            })[0].long_name;

                            var CityData = data["results"][0]["postcode_localities"];
                            _.forEach(CityData, function (value, key) {
                                FinalCity.push({
                                    "City_code": value,
                                    "Name": value
                                });
                            });

                            var state = _.filter(data["results"][0]["address_components"], function (data) {
                                return data.types[0] === "administrative_area_level_1"
                            })[0].long_name;


                            var SelectedCity = { value: FinalCity[0].City_code, label: FinalCity[0].Name }

                            var SelectedState = { value: state, label: state }

                            if (countryShortName === this.state.selectedToCountry.label) {
                                this.setState({
                                    toCityAutoComplete: FinalCity.length ? true : false,
                                    toStateAutoComplete: this.state.toStateList.length ? true : false,
                                    toGoogleAPICityList: FinalCity,
                                    toState: this.state.toStateList.length ? SelectedState : state,
                                    toCity: SelectedCity
                                })
                            } else {
                                this.setState({
                                    toCityAutoComplete: false,
                                    toStateAutoComplete: this.state.toStateList.length ? true : false,
                                    toGoogleAPICityList: [],
                                    toState: "",
                                    toCity: ""
                                })
                            }

                        } else if (data["results"][0]) {

                            var FinalCity = [];
                            var city = "";
                            var countryShortName = "";

                            countryShortName = _.filter(data["results"][0]["address_components"], function (data) {
                                return data.types[0] === "country"
                            })[0].long_name;

                            if (city == "" && (_.filter(data["results"][0]["address_components"], function (data) { return data.types[0] === "locality" })).length > 0) {
                                city = _.filter(data["results"][0]["address_components"], function (data) {
                                    return data.types[0] === "locality"
                                })[0].short_name;

                            } else if (city == "" && (_.filter(data["results"][0]["address_components"], function (data) { return data.types[0] === "administrative_area_level_3" })).length > 0) {
                                city = _.filter(data["results"][0]["address_components"], function (data) {
                                    return data.types[0] === "administrative_area_level_3"
                                })[0].short_name;

                            } else if (city == "" && (_.filter(data["results"][0]["address_components"], function (data) { return data.types[0] === "political" })).length > 0) {
                                city = _.filter(data["results"][0]["address_components"], function (data) {
                                    return data.types[0] === "political"
                                })[0].short_name;

                            } else if (city == "" && (_.filter(data["results"][0]["address_components"], function (data) { return data.types[0] === "neighborhood" })).length > 0) {
                                city = _.filter(data["results"][0]["address_components"], function (data) {
                                    return data.types[0] === "neighborhood"
                                })[0].short_name;

                            } else if (city == "" && (_.filter(data["results"][0]["address_components"], function (data) { return data.types[0] === "administrative_area_level_2" })).length > 0) {
                                city = _.filter(data["results"][0]["address_components"], function (data) {
                                    return data.types[0] === "administrative_area_level_2"
                                })[0].long_name;

                            } else if (city == "" && (_.filter(data["results"][0]["address_components"], function (data) { return data.types[0] === "administrative_area_level_1" })).length > 0) {
                                city = _.filter(data["results"][0]["address_components"], function (data) {
                                    return data.types[0] === "administrative_area_level_1"
                                })[0].long_name;

                            } else if (city == "") {
                                city = ""
                            }

                            var state = _.filter(data["results"][0]["address_components"], function (data) {
                                return data.types[0] === "administrative_area_level_1"
                            })[0].long_name;


                            FinalCity.push({
                                "City_code": city,
                                "Name": city
                            });

                            var SelectedCity = { value: FinalCity[0].City_code, label: FinalCity[0].Name }

                            var SelectedState = { value: state, label: state }

                            if (countryShortName === this.state.selectedToCountry.label) {
                                this.setState({
                                    toCityAutoComplete: FinalCity.length ? true : false,
                                    toStateAutoComplete: this.state.toStateList.length ? true : false,
                                    toGoogleAPICityList: FinalCity,
                                    toState: this.state.toStateList.length ? SelectedState : state,
                                    toCity: SelectedCity
                                })
                            } else {
                                this.setState({
                                    toCityAutoComplete: false,
                                    toStateAutoComplete: this.state.toStateList.length ? true : false,
                                    toGoogleAPICityList: [],
                                    toState: "",
                                    toCity: ""
                                })
                            }

                        }
                    }
                    else {
                        this.setState({
                            toCityAutoComplete: false,
                            toStateAutoComplete: this.state.toStateList.length ? true : false,
                            toGoogleAPICityList: [],
                            toState: "",
                            toCity: ""
                        })
                    }

                });
        }
    }

    handleBlur = (event, type) => {
        if (type === "FromZipCode") {
            let Fromaddress = this.state.FromAddress;
            Fromaddress.ZipCode = event.target.value;
            this.setState({ FromAddress: Fromaddress });
            this.senderZipChange(event.target.value);
        }
        else if (type === "ToZipCode") {
            let toAddress = this.state.ToAddress;
            toAddress.ZipCode = event.target.value;
            this.setState({ ToAddress: toAddress });
            this.recipientZipChange(event.target.value);
        }
    }

    ChangeToCity = (event, value) => {
        if (value != null) {
            this.setState({ toCity: value });
        }
    }

    ChangeToState = (event, value) => {
        if (value != null) {
            this.setState({ toState: value });
        }
    }

    ChangeFromCity = (event, value) => {
        if (value != null) {
            this.setState({ fromCity: value });
        }
    }

    ChangeFromState = (event, value) => {
        if (value != null) {
            this.setState({ fromState: value });
        }
    }

    getPackageDetail() {
        try {
            let data = {
                ShippingID: this.props.history.location.state.ShipppingID
            }
            api.post("scheduleshipment/getShipmentPackageByID", data).then(res => {
                if (res.success) {
                    if (res.data.length) {
                        var l = 0;
                        res.data.map(Obj => {
                            Obj.Index =  l;
                            l++;
                            return Obj;
                        })
                        this.setState({
                            PackageList: res.data,
                            PackageType: res.data[0].PackageType,
                            TotalPackages: res.data[0].TotalPackages
                        });
                    }
                }
            }).catch(err => {
                console.log(err);
            })
        }
        catch (err) {
            console.log("error", err);
        }
    }

    dateChange = (date , type , index) => {
        if(type === "InvoiceDate"){
            let paymentInvoiceList = this.state.PaymentList;
            let idx = paymentInvoiceList.findIndex(x => x.Index === index);
            paymentInvoiceList[idx][type] = date;
            this.setState({PaymentList : paymentInvoiceList});
        }
        else if(type === "PaymentIssuedDate"  || type === "DatePaid"){
            let paymentIssued = this.state.paymentIssued;
            let idx = paymentIssued.findIndex(x => x.Index === index);
            paymentIssued[idx][type] = date;
            this.setState({paymentIssued : paymentIssued});
        }
        else if(type === "PaymentReceivedDate"){
            let paymentReceived = this.state.paymentReceived;
            let idx = paymentReceived.findIndex(x => x.Index === index);
            paymentReceived[idx][type] = date;
            this.setState({paymentReceived : paymentReceived});
        }
        else if(type === "PaidDate"){
            let paymentMethod = this.state.paymentMethod;
            let idx = paymentMethod.findIndex(x => x.Index === index);
            paymentMethod[idx][type] = date;
            this.setState({paymentMethod : paymentMethod});
        }
    }

    handleChangeInvoiceAccount = (event, type, index) => {

        const { value } = event.target;
        const PaymentList = this.state.PaymentList;
        let idx = PaymentList.findIndex(x =>x.Index === index);
        if (type === "Description" || type === "Quantity" || type === "Amount" || type === "TotalAmount") {
            PaymentList[idx][type] = value;
        }
        this.setState({ PaymentList: PaymentList });
    }

    handleChangepaymentReceived = (event, type, index) => {
        const { value } = event.target;
        const paymentReceived = this.state.paymentReceived;
        let idx = paymentReceived.findIndex(x =>x.Index === index);
        if (type === "Amount" || type === "ConfirmationNumber") {
            paymentReceived[idx][type] = value;
        }
        this.setState({ paymentReceived: paymentReceived });

    }

    handleChangeviewPaymentIssued = (event, type, index) => {
        const { value } = event.target;
        const paymentIssued = this.state.paymentIssued;
        let idx = paymentIssued.findIndex(x => x.Index = index);
        if (type === "InvoiceNumber" || type === "Amount" || type === "PaidStatus") {
            paymentIssued[idx][type] = value;
        }
        this.setState({ paymentIssued: paymentIssued });

    }

    handleChangeviewPaymentMethod = (event, type, index) => {
        const { value } = event.target;
        const paymentMethod = this.state.paymentMethod;
        let idx = paymentMethod.findIndex(x => x.Index = index);
        if (type === "PackageContent") {
            paymentMethod[idx][type] = value;
        }
        else if (type === "RoutingNumber" || type === "CardExpiry" || type === "CardZipCode" || type === "InvoiceAmount") {
            paymentMethod[idx][type] = value;
        }
        else if (type === "PaidDate") {
            paymentMethod[idx][type] = value;
        }
        this.setState({ paymentMethod: paymentMethod });

    }

    handleChangePackage = (event, type, index) => {
        const { value } = event.target;
        const PackageList = this.state.PackageList;
        var idx = PackageList.findIndex(x => x.Index === index);
        if (type === "PackageContent") {
            PackageList[idx][type] = value;
        }
        else if (type === "Sequence" || type === "EstimetedWeight") {
            if (value.length < 4) {
                PackageList[idx][type] = value.replace(/\D/, '');
            }
            else {
                PackageList[idx][type] = 0;
            }
        }
        else if (type === "Height" || type === "Width" || type === "Length") {
            if (value.length < 3) {
                PackageList[idx][type] = value.replace(/\D/, '');
            }
            else {
                PackageList[idx][type] = 0;
            }
        }
        else if (type === "ChargableWeight" || type === "CFT") {
            PackageList[idx][type] = value.replace(/\D/, '');
        }
        else if (type === "InsuredValue") {
            if (value.length < 5) {
                PackageList[idx][type] = value.replace(/\D/, '');
            }
            else {
                PackageList[idx][type] = 0;
            }
        }
        // else{
        //     
        // }
        this.setState({ PackageList: PackageList });
    }

    selectChangeTab2 = (event, type, idx) => {
        let index = this.state.commercialList.findIndex(x => x.Index === idx);
        if (type === "TV") {
            let packgeList = this.state.PackageList;
            packgeList[index][type] = event.target.value;
            this.setState({ PackageList: packgeList });
        }
        else if (type === "Stretch") {
            let packgeList = this.state.PackageList;
            packgeList[index][type] = event.target.value;
            this.setState({ PackageList: packgeList });
        }
        else if (type === "Crating") {
            let packgeList = this.state.PackageList;
            packgeList[index][type] = event.target.value;
            this.setState({ PackageList: packgeList });
        }
        else if (type === "Repack") {
            let packgeList = this.state.PackageList;
            packgeList[index][type] = event.target.value;
            this.setState({ PackageList: packgeList });
        }
        else if (type === "PackedType") {
            let packgeList = this.state.PackageList;
            packgeList[index][type] = event.target.value;
            this.setState({ PackageList: packgeList });

        }
    }

    optionYes = () => {
        return this.state.YesNo.map(content => {
            return (
                <MenuItem classes={{ root: classes.selectMenuItem }} value={content.value} > {content.label}  </MenuItem>
            )
        })
    }

    packedBy = () => {
        return this.state.packedBy.map(content => {
            return (
                <MenuItem classes={{ root: classes.selectMenuItem }} value={content.value} > {content.label}  </MenuItem>
            )
        })
    }


    addPackageRow = () => {
        var row = {
            EstimetedWeight: 0,
            Height: 0,
            Length: 0,
            Width: 0,
            ChargableWeight: 0,
            Sequence: 0,
            CreatedBy: CommonConfig.loggedInUserData().Name,
            TV: false,
            Crating: false,
            Stretch: false,
            Repack: false,
            PackageContent: "",
            CFT: 0,
            PackedType: "",
            ShippingPackageDetailID : null,
            InsuredValue: 0,
            Status: "Active",
            Index : this.state.PackageList.length + 1
        }



        this.setState({ PackageList: [...this.state.PackageList, row] });
    }

    removePackageRow = (index) => {
        var PackageList = this.state.PackageList;
        let Index = this.state.PackageList.findIndex(x => x.Index === index);
        if(Index !== -1){
            PackageList[Index]["Status"] = "Inactive";
            this.setState({ PackageList: PackageList });
        }
    }


    viewPackage = () => {
        return this.state.PackageList.filter(x => x.Status === "Active").map((packages, idx) => {
            const Crating = CommonConfig.isEmpty(packages.Crating.data) !== true ? (packages.Crating.data[0] === 0 ? false : true) : packages.Crating;
            const TV = CommonConfig.isEmpty(packages.TV.data) !== true ? (packages.TV.data[0] === 0 ? false : true) : packages.TV;
            const Stretch = CommonConfig.isEmpty(packages.Stretch.data) !== true ? (packages.Stretch.data[0] === 0 ? false : true) : packages.Stretch;
            const Repack = CommonConfig.isEmpty(packages.Repack.data) !== true ? (packages.Repack.data[0] === 0 ? false : true) : packages.Repack;
            return (
                <tr>

                    <td className="text-align-right">
                        <CustomInput
                            id="number"
                            // type="number"
                            inputProps={{
                                value: idx + 1
                            }}
                        />
                    </td>
                    {this.state.ShipmentType.value == "Ocean" ?
                        <>
                            <td>
                                <CustomInput
                                    type="number"
                                    name="sequence"
                                    id="sequence"
                                    inputProps={{
                                        value: packages.Sequence,
                                        onChange: (event) => this.handleChangePackage(event, "Sequence", packages.Index)
                                    }}
                                />
                            </td>
                            <td>

                                <div className="table-select small">
                                    <FormControl className={classes.formControl} fullWidth>
                                        <Select id="package_number" name="package_number" value={TV} className="form-control" onChange={(event) => this.selectChangeTab2(event, "TV", packages.Index)}>
                                            {this.optionYes()}</Select>
                                    </FormControl>
                                </div>
                            </td>
                            <td>

                                <div className="table-select small">
                                    <FormControl className={classes.formControl} fullWidth>
                                        <Select id="package_number" name="package_number" value={Stretch} className="form-control" onChange={(event) => this.selectChangeTab2(event, "Stretch", packages.Index)}>
                                            {this.optionYes()}</Select>
                                    </FormControl>
                                </div>
                            </td>
                            <td>

                                <div className="table-select small">
                                    <FormControl className={classes.formControl} fullWidth>
                                        <Select id="package_number" name="package_number" value={Repack} className="form-control" onChange={(event) => this.selectChangeTab2(event, "Repack", packages.Index)}>
                                            {this.optionYes()}</Select>
                                    </FormControl>
                                </div>
                            </td>
                            <td>
                                <div className="table-select small">
                                    <FormControl className={classes.formControl} fullWidth>
                                        <Select id="package_number" name="package_number" value={Crating} className="form-control" onChange={(event) => this.selectChangeTab2(event, "Crating", packages.Index)}>
                                            {this.optionYes()}</Select>
                                    </FormControl>
                                </div>
                            </td>
                            <td>
                                <div className="width-md">
                                    <CustomInput
                                        type="number"
                                        name="packagecontent"
                                        id="proposaltype"
                                        inputProps={{
                                            value: packages.PackageContent,
                                            onChange: (event) => this.handleChangePackage(event, "PackageContent", packages.Index)
                                        }}
                                    />
                                </div>
                            </td>
                        </>
                        :
                        null
                    }
                    <td>
                        <CustomInput
                            id="proposaltype"
                            type="weight"
                            name="weight"
                            inputProps={{
                                value: packages.EstimetedWeight,
                                onChange: (event) => this.handleChangePackage(event, "EstimetedWeight", packages.Index)
                            }}
                        />
                    </td>
                    <td>
                        <CustomInput
                            type="length"
                            name="length"
                            id="proposaltype"
                            inputProps={{
                                value: packages.Length,
                                onChange: (event) => this.handleChangePackage(event, "Length", packages.Index)
                            }}
                        />
                    </td>
                    <td>
                        <CustomInput
                            type="number"
                            name="width"
                            id="proposaltype"
                            inputProps={{
                                value: packages.Width,
                                onChange: (event) => this.handleChangePackage(event, "Width", packages.Index)
                            }}
                        />
                    </td>
                    <td>
                        <CustomInput
                            type="number"
                            name="height"
                            id="proposaltype"
                            inputProps={{
                                value: packages.Height,
                                onChange: (event) => this.handleChangePackage(event, "Height", packages.Index)
                            }}
                        />
                    </td>
                    <td>

                        <CustomInput
                            type="number"
                            name="chargableweight"
                            id="proposaltype"
                            inputProps={{
                                value: packages.ChargableWeight,
                                onChange: (event) => this.handleChangePackage(event, "ChargableWeight", packages.Index)
                            }}
                        />
                    </td>
                    {this.state.ShipmentType.value !== "Ocean" ?
                        <td>
                            <CustomInput
                                type="number"
                                name="insurance"
                                id="insurance"
                                inputProps={{
                                    value: packages.InsuredValue,
                                    onChange: (event) => this.handleChangePackage(event, "InsuredValue", packages.Index)
                                }}
                            />
                        </td>
                        : null}

                    {this.state.ShipmentType.value === "Ocean" ?
                        <>
                            <td>
                                <CustomInput
                                    type="number"
                                    name="cft"
                                    id="proposaltype"
                                    inputProps={{
                                        value: packages.CFT,
                                        onChange: (event) => this.handleChangePackage(event, "CFT", packages.Index)
                                    }}
                                />
                            </td>
                            <td>
                                <div className="table-select">
                                    <FormControl className={classes.formControl} fullWidth>
                                        <Select id="package_number" name="package_number" value={packages.PackedType} className="form-control" onChange={(event) => this.selectChangeTab2(event, "PackedType", packages.Index)}>
                                            {this.packedBy()}</Select>
                                    </FormControl>
                                </div>
                            </td>
                        </>
                        : null
                    }
                    <td>
                        <span>{packages.CreatedBy}</span>
                    </td>
                    <td>
                        <div className="pck-subbtn">
                            <Button justIcon color="danger" className="Plus-btn " onClick={() => this.removePackageRow(packages.Index)}>
                                <i className={"fas fa-minus"} />
                            </Button>
                            {/* <DeleteIcon  onClick={() => this.removePackageRow(idx)} /> */}
                            {this.state.PackageList.filter(x => x.Status === "Active").length === idx + 1 ?
                                // <Icon color="secondary" onClick={() => this.addPackageRow()}>add_circle</Icon>
                                <Button justIcon color="facebook" onClick={() => this.addPackageRow()} className="Plus-btn ">
                                    <i className={"fas fa-plus"} />
                                </Button>
                                : null
                            }
                        </div>
                    </td>
                    {/* {this.state.PackageList.length === idx+1 ? 
                <td className="text-align-right"><Button onClick = {() => this.addPackageRow()}>Add Row</Button></td>
                : null
                } */}
                </tr>

            )
        })
    }

    changePackage = (event, type) => {
        if (type === "PackageType") {
            this.setState({ PackageType: event.target.value });
            if (event.target.value === "Envelop") {
                var PackageList = this.state.PackageList;
                PackageList[0]["EstimetedWeight"] = 0.5;
                PackageList[0]["Quantity"] = 1;
                PackageList[0]["Length"] = 10;
                PackageList[0]["Width"] = 13;
                PackageList[0]["Height"] = 1;
                PackageList[0]["ChargableWeight"] = 0.5;
                PackageList[0]["CFT"] = 0.0;
                PackageList[0]["Status"] = "Active";
                this.setState({ PackageList: PackageList });
            }
        }
        else if (type === "TotalPackage") {
            this.setState({ TotalPackages: event.target.value });
        }
    }

    getCommercialInvoiceDetail() {
        try {
            let data = {
                ShippingID: this.props.history.location.state.ShipppingID
            }
            api.post("scheduleshipment/getShipmentCommercialInvoiceByID", data).then(res => {
                if (res.success) {
                    var l = 0;
                    res.data.map(Obj => {
                        Obj.Index =  l;
                        l++;
                        return Obj;
                    })
                    this.setState({ commercialList: res.data });
                }
            }).catch(err => {
                console.log("error..", err);
            })
        }
        catch (err) {
            console.log(err);
        }
    }

    removeCommercialInvoice = (index) => {
        var commercialList = this.state.commercialList;
        let Index = this.state.commercialList.findIndex(x => x.Index === index);
        if(Index !== -1){
            commercialList[Index]["Status"] = "Inactive";
            this.setState({ commercialList: commercialList });
        }
    }

    addnewRowCommercial = () => {
        const row = {
            PackageNumber: 0,
            Status: "Active",
            ContentDescription: "",
            ShippingCommercialInvoiceID : null,
            Quantity: 0,
            ValuePerQuantity: 0,
            TotalValue: 0,
            Index : this.state.commercialList.length + 1
        }
        this.setState({ commercialList: [...this.state.commercialList, row] });
    }

    viewCommercialInvoice = () => {
        return this.state.commercialList.filter(x => x.Status === "Active").map((commercial, idx) => {
            return (

                <tr>
                    <td className="text-align-right">
                        <CustomInput
                            id="proposaltype"
                            inputProps={{
                                onChange: (event) => this.handleCommercialInvoiceChange(event, "PackageNumber", commercial.Index),
                                value: commercial.PackageNumber
                            }}
                        />
                    </td>
                    <td>
                        <div className="width-md">
                            <CustomInput
                                id="proposaltype"
                                inputProps={{
                                    onChange: (event) => this.handleCommercialInvoiceChange(event, "ContentDescription", commercial.Index),
                                    value: commercial.ContentDescription
                                }}
                            />
                        </div>
                    </td>
                    <td>
                        <CustomInput
                            id="proposaltype"
                            type="number"
                            inputProps={{
                                onChange: (event) => this.handleCommercialInvoiceChange(event, "Quantity", commercial.Index),
                                value: commercial.Quantity
                            }}
                        />
                    </td>
                    <td>
                        <CustomInput
                            id="proposaltype"
                            type="number"
                            inputProps={{
                                onChange: (event) => this.handleCommercialInvoiceChange(event, "ValuePerQuantity", commercial.Index),
                                value: commercial.ValuePerQuantity
                            }}
                        />
                    </td>
                    <td>
                        <CustomInput
                            id="proposaltype"
                            type="number"
                            inputProps={{
                                onChange: (event) => this.handleCommercialInvoiceChange(event, "TotalValue", commercial.Index),
                                value: commercial.TotalValue
                            }}
                        />
                    </td>
                    <td>
                        <Button justIcon color="danger" className="Plus-btn " onClick={() => this.removeCommercialInvoice(commercial.Index)}>
                            <i className={"fas fa-minus"} />
                        </Button>

                        {this.state.commercialList.filter(x => x.Status === "Active").length === idx + 1 ?
                            <Button justIcon color="facebook" onClick={() => this.addnewRowCommercial()} className="Plus-btn ">
                                <i className={"fas fa-plus"} />
                            </Button>

                            :
                            null
                        }
                    </td>
                </tr>
            )
        })
    }

    handleCommercialInvoiceChange = (event, type, index) => {
        let idx = this.state.commercialList.findIndex(x => x.Index === index);
        if (type === "PackageNumber") {
            let commercialList = this.state.commercialList;
            if (event.target.value.length < 4) {
                commercialList[idx][type] = event.target.value.replace(/\D/, '');
            }
            else {
                commercialList[idx][type] = 0;
            }
            this.setState({ commercialList: commercialList });
        }
        else if (type === "ContentDescription") {
            let commercialList = this.state.commercialList;
            commercialList[idx][type] = event.target.value;
            this.setState({ commercialList: commercialList });

        }
        else if (type === "Quantity") {
            let commercialList = this.state.commercialList;
            if (event.target.value.length < 4) {
                commercialList[idx][type] = event.target.value.replace(/\D/, '');
            }
            else {
                commercialList[idx][type] = 0;
            }
            this.setState({ commercialList: commercialList });

        }
        else if (type === "ValuePerQuantity") {
            let commercialList = this.state.commercialList;
            commercialList[idx][type] = event.target.value.replace(/\D/, '');
            this.setState({ commercialList: commercialList });

        }
        else if (type === "TotalValue") {
            let commercialList = this.state.commercialList;
            commercialList[idx][type] = event.target.value.replace(/\D/, '');
            this.setState({ commercialList: commercialList });

        }

    }

    getAccountDetail() {
        try {
            let data = {
                ShippingID: this.props.history.location.state.ShipppingID
            }
            api.post("scheduleshipment/getAccountDetail", data).then(res => {
                if (res.success) {
                    var i = 0;
                    res.data.InvoiceData.map(Obj => {
                        Obj.Index =  i;
                        i++;
                        return Obj;
                    })
                    var j = 0;
                    res.data.PaymentReceivedData.map(Obj => {
                        Obj.Index =  j;
                        j++;
                        return Obj;
                    })
                    
                    var k = 0;
                    res.data.PaymentIssuedData.map(Obj => {
                        Obj.Index =  k;
                        k++;
                        return Obj;
                    })
                    
                    var l = 0;
                    res.data.PaymentDetailData.map(Obj => {
                        Obj.Index =  l;
                        l++;
                        return Obj;
                    })

                    this.setState({
                        PaymentList: res.data.InvoiceData,
                        paymentReceived: res.data.PaymentReceivedData,
                        paymentIssued: res.data.PaymentIssuedData,
                        paymentMethod: res.data.PaymentDetailData,

                    });
                    this.addnewRowInvoice();
                    this.addRowPaymentReceived();
                    this.addRowPaymentIssued();
                    this.addRowPaymentMethod();
                }
            }).catch(err => {
                console.log("error...", err);
            })
        }
        catch (err) {
            console.log("error", err);
        }

    }

    getServiceDescription() {

        try {
            let data = {
                stringMapType: "INVENTORY"
            }

            api.post("stringMap/getstringMap", data).then(result => {
                this.setState({ ServiceDescriptionList: result.data })
            }).catch(err => {
                console.log(err);
            })
        }
        catch (err) {
            console.log("error", err);
        }
    }

    getpaymentType() {

        try {
            let data = {
                stringMapType: "PAYMENTTYPE"
            }

            api.post("stringMap/getstringMap", data).then(result => {
                this.setState({ PaymentTypeList: result.data })
            }).catch(err => {
                console.log(err);
            })
        }
        catch (err) {
            console.log("error", err);
        }
    }

    getVendorName() {
        try {
            api.get("vendor/getVendorNameList").then(result => {
                this.setState({ VendorList: result.data })
            }).catch(err => {
                console.log(err);
            })
        }
        catch (err) {
            console.log("error", err);
        }

    }

    renderServiceDescription = () => {
        return this.state.ServiceDescriptionList.map(content => {
            return (
                <MenuItem classes={{ root: classes.selectMenuItem }} value={content.Description} > {content.Description}  </MenuItem>
            )
        })
    }

    addnewRowInvoice = () => {
        const row = {
            ServiceDescription :"",
            InvoiceDate : "",
            Descriptiom : "",
            Quantity : 0,
            Amount : 0,
            TotalAmout :0,
            CreatedByName : CommonConfig.loggedInUserData().Name,
            Status : "Active",
            ShippingInvoiceID:null,
            Index : this.state.PaymentList.length + 1
        }
        this.setState({ PaymentList: [...this.state.PaymentList, row] });
    }

    addRowPaymentReceived = () => {
        const row = {
            PaymentReceivedDate : "",
            PaymentType : "",
            Amount :0,
            ConfirmationNumber:"",
            CreatedByName : CommonConfig.loggedInUserData().Name,
            Status : "Active",
            ShippingPaymentReceivedID : null,
            Index : this.state.paymentReceived.length + 1 
        }
        this.setState({ paymentReceived: [...this.state.paymentReceived, row] });
    }

    addRowPaymentIssued = () => {
        const row = {
            PaymentIssuedDate : "",
            VendorName : "",
            InvoiceNumber : "",
            DatePaid : "",
            CreatedByName : CommonConfig.loggedInUserData().Name,
            Status : "Active",
            ShippingPaymentIssuedID : null,
            Index : this.state.paymentIssued.length + 1,
        }
        this.setState({ paymentIssued: [...this.state.paymentIssued, row] });
    }

    addRowPaymentMethod = () => {
        const row = {
            CreatedByName : CommonConfig.loggedInUserData().Name,
            Status : "Active",
            PaymentID : null,
            AccountNumber:"",
            BankName:"",
            CardCVV:"",
            CardName:"",
            CardExpiry:"",
            CardNumber:"",
            CardType:"",
            CardZipCode:"",
            ContactName:"",
            InvoiceAmount:"",
            NameonAccount:"",
            PaidDate:"",
            PaymentStatus:"New",
            PaymentType:"",
            RoutingNumber:"",
            Index : this.state.paymentMethod.length + 1
        }
        this.setState({ paymentMethod: [...this.state.paymentMethod, row] });
    }

    removePaymentRecieved = (index) => {
        var paymentList = this.state.paymentReceived;
        let Index = this.state.paymentReceived.findIndex(x => x.Index === index);
        if(Index !== -1){
            paymentList[Index]["Status"] = "Inactive";
            this.setState({ paymentReceived: paymentList });
        }
    }

    removePaymentIssued = (index) => {
        var paymentList = this.state.paymentIssued;
        let Index = this.state.paymentIssued.findIndex(x => x.Index === index);
        if(Index !== -1){
            paymentList[Index]["Status"] = "Inactive";
            this.setState({ paymentIssued: paymentList });
        }
    }

    removeInvoice = (index) => {
        ;
        var paymentList = this.state.PaymentList;
        let Index = this.state.PaymentList.findIndex(x => x.Index === index);
        if(Index !== -1){
            paymentList[Index]["Status"] = "Inactive";
            this.setState({ PaymentList: paymentList });
        }
    }

    removePaymentMethod = (index) => {
        var paymentList = this.state.paymentMethod;
        let Index = this.state.paymentMethod.findIndex(x => x.Index === index);
        if(Index !== -1){
            paymentList[Index]["Status"] = "Inactive";
            this.setState({ paymentMethod: paymentList });
        }
    }

    selectChangeTab3 = (value, type , index) => {
        if(type === "ServiceDescription"){
            let paymentList = this.state.PaymentList;
            let idx = this.state.PaymentList.findIndex(x => x.Index === index);
            paymentList[idx][type] = value.value;
            this.setState({PaymentList : paymentList});
        }
        else if(type === "VendorName"){
            let paymentIssued = this.state.paymentIssued;
            let idx = this.state.paymentIssued.findIndex(x => x.Index === index);
            paymentIssued[idx][type] = value.value;
            this.setState({paymentIssued : paymentIssued});
        }
        else if(type === "PaymentType"){
            let paymentReceived = this.state.paymentReceived;
            let idx = this.state.paymentReceived.findIndex(x => x.Index === index);
            paymentReceived[idx][type] = value.value;
            this.setState({paymentReceived : paymentReceived});
        }
        else if(type === "PaymentMethod"){
            let paymentMethod = this.state.paymentMethod;
            let idx = this.state.paymentMethod.findIndex(x => x.Index === index);
            paymentMethod[idx]["PaymentType"] = value.value;
            this.setState({paymentMethod : paymentMethod});
        }
        
    }

    yesNo = () => {
        return this.state.yesNo.map(content => {
            return (
                <MenuItem classes={{ root: classes.selectMenuItem }} value={content.value} > {content.label}  </MenuItem>
            )
        })
    }

    viewInvoice = () => {
        const ServiceList = this.state.ServiceDescriptionList.map(type => { return { value: type.Description, label: type.Description } });
        return this.state.PaymentList.filter(x => x.Status === "Active").map((payment, idx) => {
            const ServiceDescription = {
                value: payment.ServiceDescription,
                label: payment.ServiceDescription
            }
            return (

                <tr>
                    <td>
                        <Datetime 
                            dateFormat={"MM/DD/YYYY"}
                            timeFormat={false} 
                            value = { moment(payment.InvoiceDate)}
                            // inputProps={{ placeholder: "Lead Date" }} 
                            onChange={(date) => this.dateChange(date,"InvoiceDate",payment.Index)} 
                            closeOnSelect={true}
                            renderInput={params => (
                            <TextField
                            // style={{marginTop:"-15px"}}
                            // error={selectfield.error}
                            // helperText={selectfield.helperText} 
                            {...params} label="Invoice Date" margin="normal" fullWidth />)}/>
                        {/* <CustomInput
                            inputProps={{
                                value: moment(payment.InvoiceDate).format(CommonConfig.dateFormat.dateOnly),
                                onChange: (event) => this.handleChangeInvoiceAccount(event, "InvoiceDate", payment.Index),
                            }} /> */}
                    </td>
                    <td>
                        <div>
                            <Autocomplete
                                id="package_number"
                                options={ServiceList}
                                value={ServiceDescription}
                                getOptionLabel={(option) => option.label}
                                onChange={(event, value) => this.selectChangeTab3(value, "ServiceDescription",payment.Index)}
                                renderInput={(params) => <TextField {...params} />}
                            />
                        </div>
                    </td>
                    <td className="text-align-right">
                        <CustomInput
                            inputProps={{
                                onChange: (event) => this.handleChangeInvoiceAccount(event, "Description", payment.Index),
                                value: payment.Description
                            }} />
                    </td>
                    <td className="text-align-right">
                        <CustomInput
                            inputProps={{
                                onChange: (event) => this.handleChangeInvoiceAccount(event, "Quantity", payment.Index),
                                value: payment.Quantity
                            }} />
                    </td>
                    <td className="text-align-right">
                        <CustomInput
                            inputProps={{
                                onChange: (event) => this.handleChangeInvoiceAccount(event, "Amount", payment.Index),
                                value: payment.Amount
                            }} />
                    </td>
                    <td className="text-align-right">
                        <CustomInput
                            inputProps={{
                                onChange: (event) => this.handleChangeInvoiceAccount(event, "TotalAmount", payment.Index),
                                value: payment.TotalAmount
                            }} />
                    </td>
                    <td>
                        <span>{payment.CreatedByName}</span>
                    </td>
                    <td>
                        <Button justIcon color="danger" className="Plus-btn " onClick={() => this.removeInvoice(payment.Index)}>
                            <i className={"fas fa-minus"} />
                        </Button>
                        {this.state.PaymentList.filter(x => x.Status === "Active").length === idx + 1 ?
                            <Button justIcon color="facebook" onClick={() => this.addnewRowInvoice()} className="Plus-btn ">
                                <i className={"fas fa-plus"} />
                            </Button>

                            : null
                        }
                    </td>
                </tr>
            )
        })
    }

    viewPaymentIssued = () => {
        const VendorList = this.state.VendorList.map(type => { return { value: type.VendorName, label: type.VendorName } });
        return this.state.paymentIssued.filter(x => x.Status === "Active").map((payment, idx) => {
            const vendorName = {
                value: payment.VendorName, label: payment.VendorName
            }
            return (
                <tr>
                    <td>
                        <Datetime 
                            dateFormat={"MM/DD/YYYY"}
                            timeFormat={false} 
                            value = { moment(payment.PaymentIssuedDate)}
                            // inputProps={{ placeholder: "Lead Date" }} 
                            onChange={(date) => this.dateChange(date,"PaymentIssuedDate",payment.Index)} 
                            closeOnSelect={true}
                            renderInput={params => (
                            <TextField
                            // style={{marginTop:"-15px"}}
                            // error={selectfield.error}
                            // helperText={selectfield.helperText} 
                            {...params} label="Issued Date" margin="normal" fullWidth />)}/>
                        {/* <CustomInput
                            inputProps={{
                                onChange: (event) => this.handleChangeviewPaymentIssued(event, "PaymentIssuedDate", payment.Index),
                                value: moment(payment.PaymentIssuedDate).format(CommonConfig.dateFormat.dateOnly)
                            }} /> */}
                    </td>
                    <td>
                        <Autocomplete
                            id="package_number"
                            options={VendorList}
                            value={vendorName}
                            getOptionLabel={(option) => option.label}
                            onChange={(event,value) => this.selectChangeTab3(value, "VendorName",payment.Index)}
                            renderInput={(params) => <TextField {...params} />}
                        />
                    </td>
                    <td className="text-align-right">
                        <CustomInput
                            inputProps={{
                                onChange: (event) => this.handleChangeviewPaymentIssued(event, "InvoiceNumber", payment.Index),
                                value: payment.InvoiceNumber
                            }} />
                    </td>
                    <td className="text-align-right">
                        <Datetime 
                                dateFormat={"MM/DD/YYYY"}
                                timeFormat={false} 
                                value = { moment(payment.DatePaid)}
                                // inputProps={{ placeholder: "Lead Date" }} 
                                onChange={(date) => this.dateChange(date,"DatePaid",payment.Index)} 
                                closeOnSelect={true}
                                renderInput={params => (
                                <TextField
                                // style={{marginTop:"-15px"}}
                                // error={selectfield.error}
                                // helperText={selectfield.helperText} 
                                {...params} label="Date Paid" margin="normal" fullWidth />)}/>
                            {/* <CustomInput
                                inputProps={{
                                    onChange: (event) => this.handleChangeviewPaymentIssued(event, "DatePaid", payment.Index),
                                    value: moment(payment.DatePaid).format(CommonConfig.dateFormat.dateOnly)
                                }} /> */}
                    </td>
                    <td>
                        <div className="table-select">
                            <FormControl className={classes.formControl} fullWidth>
                                <Select id="package_number" value={payment.PaidStatus} name="package_number" className="form-control" onChange={(event) => this.handleChangeviewPaymentIssued(event , "PaidStatus",payment.Index)}>
                                    {this.yesNo()}</Select>
                            </FormControl>
                        </div>
                    </td>
                    <td className="text-align-right">
                        <CustomInput
                            inputProps={{
                                onChange: (event) => this.handleChangeviewPaymentIssued(event, "Amount", payment.Index),
                                value: payment.Amount
                            }} />
                    </td>
                    <td>
                        <span>{payment.CreatedByName}</span>
                    </td>
                    <td>
                        <Button justIcon color="danger" className="Plus-btn " onClick={() => this.removePaymentIssued(payment.Index)}>
                            <i className={"fas fa-minus"} />
                        </Button>
                        {this.state.paymentIssued.filter(x => x.Status === "Active").length === idx + 1 ?
                            <Button justIcon color="facebook" onClick={() => this.addRowPaymentIssued()} className="Plus-btn ">
                                <i className={"fas fa-plus"} />
                            </Button>
                            : null
                        }
                    </td>
                </tr>

            )
        })
    }

    viewPaymentMethod = () => {
        const PaymentMethodType = this.state.PaymentMethodType.map(type => { return { value: type.value, label: type.label } });
        return this.state.paymentMethod.filter(x => x.Status === "Active").map((method, idx) => {
            const Paymentmethod = {
                value: method.PaymentType, label: method.PaymentType
            }
            return (
                <tr>
                    <td>
                        <Autocomplete
                            id="package_number"
                            options={PaymentMethodType}
                            value={Paymentmethod}
                            getOptionLabel={(option) => option.label}
                            onChange={(event,value) => this.selectChangeTab3(value, "PaymentMethod",method.Index)}
                            renderInput={(params) => <TextField {...params} />}
                        />
                    </td>
                    <td>
                        <CustomInput
                            inputProps={{
                                onChange: (event) => this.handleChangeviewPaymentMethod(event, "PackageNumber", method.Index),
                                value: method.PaymentType === "Credit Card" ? method.CardName : method.NameonAccount
                            }}
                        />
                    </td>
                    <td>
                        <CustomInput
                            inputProps={{
                                onChange: (event) => this.handleChangeviewPaymentMethod(event, "PackageNumber", method.Index),
                                value: method.PaymentType === "Credit Card" ? method.CardNumber : method.AccountNumber
                            }}
                        />
                        {
                            method.PaymentType === "Bank" ?
                                <CustomInput
                                    inputProps={{
                                        onChange: (event) => this.handleChangeviewPaymentMethod(event, "RoutingNumber", method.Index),
                                        value: method.RoutingNumber
                                    }}
                                />
                                : null
                        }
                    </td>
                    {/* <td className="text-align-right">
                            <CustomInput 
                                inputProps={{
                                  value:method.RoutingNumber
                                }}
                            />
                        </td> */}
                    <td className="text-align-right">
                        <Datetime 
                            dateFormat={"MM/DD/YYYY"}
                            timeFormat={false} 
                            value = { moment(method.PaidDate)}
                            // inputProps={{ placeholder: "Lead Date" }} 
                            onChange={(date) => this.dateChange(date,"PaidDate",method.Index)} 
                            closeOnSelect={true}
                            renderInput={params => (
                            <TextField
                            // style={{marginTop:"-15px"}}
                            // error={selectfield.error}
                            // helperText={selectfield.helperText} 
                            {...params} label="Date Paid" margin="normal" fullWidth />)}/>
                        {/* <CustomInput
                            inputProps={{
                                onChange: (event) => this.handleChangeviewPaymentMethod(event, "PaidDate", method.Index),
                                value: moment(method.PaidDate).format(CommonConfig.dateFormat.dateOnly)
                            }}
                        /> */}
                    </td>
                    <td className="text-align-right">
                        <CustomInput
                            inputProps={{
                                onChange: (event) => this.handleChangeviewPaymentMethod(event, "CardExpiry", method.Index),
                                value: method.CardExpiry
                            }}
                        />
                    </td>
                    <td className="text-align-right">
                        <CustomInput
                            inputProps={{
                                onChange: (event) => this.handleChangeviewPaymentMethod(event, "CardZipCode", method.Index),
                                value: method.CardZipCode
                            }}
                        />
                    </td>
                    <td className="text-align-right">
                        <CustomInput
                            inputProps={{
                                onChange: (event) => this.handleChangeviewPaymentMethod(event, "InvoiceAmount", method.Index),
                                value: method.InvoiceAmount
                            }}
                        />
                    </td>
                    <td>
                        <span>{method.CreatedByName}</span>
                    </td>
                    <td>
                        <Button justIcon color="danger" className="Plus-btn " onClick={() => this.removePaymentMethod(method.Index)}>
                            <i className={"fas fa-minus"} />
                        </Button>
                        {this.state.paymentMethod.filter(x => x.Status === "Active").length === idx + 1 ?
                            <Button justIcon color="facebook" onClick={() => this.addRowPaymentMethod()} className="Plus-btn ">
                                <i className={"fas fa-plus"} />
                            </Button>
                            : null
                        }
                    </td>
                </tr>
            )
        })
    }

    paymentReceived = () => {
        const PaymentTypeList = this.state.PaymentTypeList.map(type => { return { value: type.Description, label: type.Description } });
        return this.state.paymentReceived.filter(x => x.Status === "Active").map((payment, idx) => {
            const paymentType = {
                value: payment.PaymentType, label: payment.PaymentType
            }
            return (

                <tr>
                    <td>
                        <Datetime 
                                dateFormat={"MM/DD/YYYY"}
                                timeFormat={false} 
                                value = { moment(payment.PaymentReceivedDate)}
                                // inputProps={{ placeholder: "Lead Date" }} 
                                onChange={(date) => this.dateChange(date,"PaymentReceivedDate",payment.Index)} 
                                closeOnSelect={true}
                                renderInput={params => (
                                <TextField
                                // style={{marginTop:"-15px"}}
                                // error={selectfield.error}
                                // helperText={selectfield.helperText} 
                                {...params} label="Received Date" margin="normal" fullWidth />)}/>
                        {/* <CustomInput
                            inputProps={{
                                onChange: (event) => this.handleChangepaymentReceived(event, "PaymentReceivedDate", payment.Index),
                                value: moment(payment.PaymentReceivedDate).format(CommonConfig.dateFormat.dateOnly)
                            }}
                        /> */}
                    </td>
                    <td>
                        <Autocomplete
                            id="package_number"
                            options={PaymentTypeList}
                            value={paymentType}
                            getOptionLabel={(option) => option.label}
                            onChange={(event,value) => this.selectChangeTab3(value, "PaymentType",payment.Index)}
                            renderInput={(params) => <TextField {...params} />}
                        />
                    </td>
                    <td className="text-align-right">
                        <CustomInput
                            inputProps={{
                                onChange: (event) => this.handleChangepaymentReceived(event, "ConfirmationNumber", payment.Index),
                                value: payment.ConfirmationNumber
                            }}
                        />
                    </td>
                    <td className="text-align-right">
                        <CustomInput
                        // inputProps={{
                        //   value:payment.ConfirmationNumber
                        // }}
                        />
                    </td>
                    <td className="text-align-right">
                        <CustomInput
                            inputProps={{
                                onChange: (event) => this.handleChangepaymentReceived(event, "Amount", payment.Index),
                                value: payment.Amount
                            }}
                        />
                    </td>
                    <td>
                        <span>{payment.CreatedByName}</span>
                    </td>
                    <td>
                        <Button justIcon color="danger" className="Plus-btn " onClick={() => this.removePaymentRecieved(payment.Index)}>
                            <i className={"fas fa-minus"} />
                        </Button>
                        {this.state.paymentReceived.filter(x => x.Status === "Active").length === idx + 1 ?
                            <Button justIcon color="facebook" onClick={() => this.addRowPaymentReceived()} className="Plus-btn ">
                                <i className={"fas fa-plus"} />
                            </Button>
                            : null
                        }
                    </td>
                </tr>
            )
        })
    }

    trackingService() {
        try {
            api.get("userManagement/getServiceName").then(result => {
                if (result.success) {
                    this.setState({ TrackingServiceList: result.data.ServiceName });
                }
            }).catch(err => {
                console.log(err);
            })
        }
        catch (err) {
            console.log("error", err);
        }
    }

    removeTrackingNumber = (index) => {
        var trackingNumberList = this.state.trackingNumberList;
        trackingNumberList.splice(index, 1);
        this.setState({ trackingNumberList: trackingNumberList });
    }

    addnewRowTrackingNumber = () => {
        const row = {
            tracking_id: '',
            Carrier: '',
            Type: '',
            Comments: '',
            Added_by: CommonConfig.loggedInUserData().Name
        }
        this.setState({ trackingNumberList: [...this.state.trackingNumberList, row] });
    }

    activeInactive = () => {
        return this.state.activeInactive.map(content => {
            return (
                <MenuItem classes={{ root: useStyles.selectMenuItem }} value={content.value} > {content.label}  </MenuItem>
            )
        })
    }

    viewTrackingNumber = () => {
        const serviceName = this.state.TrackingServiceList.map(type => { return { value: type.MainServiceName, label: type.MainServiceName } });
        return this.state.trackingNumberList.map((trackingnumber, idx) => {
            return (

                <tr>
                    <td className="text-align-right">

                        <CustomInput
                            id="proposaltype"
                            inputProps={{
                                value: idx + 1
                            }}
                        />
                    </td>
                    <td>

                        <CustomInput
                            id="proposaltype"

                            inputProps={{
                                disabled: true,
                                value: moment().format(CommonConfig.dateFormat.dateOnly),
                                onChange: event => this.change(event, "Username"),
                                // endAdornment: (
                                //   <InputAdornment
                                //     position="end"
                                //     className={classes.inputAdornment}
                                //   >
                                //     <Icon className={classes.User}>
                                //       person
                                //                                             </Icon>
                                //   </InputAdornment>
                                // )
                            }}
                        />
                    </td>
                    <td className="text-align-right">

                        <CustomInput
                            id="proposaltype"
                            type="number"
                            inputProps={{
                                value: trackingnumber.tracking_id
                            }}
                        />
                    </td>
                    <td>
                        <div>
                            <Autocomplete
                                id="combo-box-demo"
                                options={serviceName}
                                getOptionLabel={(option) => option.label}
                                renderInput={(params) => <TextField {...params} />}
                            >
                            </Autocomplete>
                        </div>
                        {/* <CustomInput
                  id="proposaltype"
                  type="number"
                  inputProps={{
                    value: trackingnumber.Carrier
                  }}
                /> */}
                    </td>
                    <td className="text-align-right">

                        <CustomInput
                            id="proposaltype"
                            type="number"
                            inputProps={{
                                value: trackingnumber.Comments
                            }}
                        />
                    </td>
                    <td className="text-align-right">
                        {/* 
                <CustomInput
                  id="proposaltype"
                  type="number"
                  inputProps={{
                    disabled:true,
                    value: 
                  }}
                /> */}
                        <span>{trackingnumber.Added_by}</span>
                    </td>
                    <td>
                        <div className="table-select">
                            <FormControl className={useStyles.formControl} fullWidth>
                                <Select id="package_number" name="package_number" className="form-control" onChange={() => this.handleChangePackagecontent()}>
                                    {this.activeInactive()}</Select>
                            </FormControl>
                        </div>
                    </td>
                    <td>
                        <Button justIcon color="danger" className="Plus-btn" onClick={() => this.removeTrackingNumber(idx)}>
                            <i className={"fas fa-minus"} />
                        </Button>
                        {this.state.trackingNumberList.length === idx + 1 ?
                            <Button justIcon color="facebook" onClick={() => this.addnewRowTrackingNumber()} className="Plus-btn ">
                                <i className={"fas fa-plus"} />
                            </Button>
                            : null
                        } </td>
                </tr>
            )
        })
    }

    AddNewRowData = () => {
        let attachments = this.state.Attachments;
        let IsValid = true;
        for (let i = 0; i < this.state.Attachments.length; i++) {
            if (!attachments[i].hasOwnProperty("AttachmentName")) {
                IsValid = false;
            }
        }
        var AttachmentList = this.state.Attachments.filter(x => (x.Status === "Active" && (x.FileName === "" || x.FileName === null)));
        if (AttachmentList.length === 0 && IsValid) {
            const objAttachment = {
                Index: AttachmentList.filter(x => x.Status === "Active").length + 1,
                FileName: '',
                Status: "Active",
                DocumentCreatedOn: moment().format(CommonConfig.dateFormat.dateOnly),
                DocumentCreatedBy: CommonConfig.loggedInUserData().Name,
            };
            this.setState({ Attachments: [...this.state.Attachments, objAttachment] });
        }
        else {
            cogoToast.error("Please fill above row first");
        }

    }

    handleDocumentChange = (e, record) => {
        var Index = this.state.Attachments.indexOf(record.original);
        this.state.Attachments[Index]["FileName"] = e.target.value;
        this.setState({ Attachments: [...this.state.Attachments] });
    }

    fileUpload = (event, record) => {
        const files = event.target.files[0];
        let AttachmentList = this.state.Attachments;
        let Index = this.state.Attachments.indexOf(record.original);
        AttachmentList[Index]["AttachmentName"] = files.name;
        AttachmentList[Index]["AttachmentType"] = files.type;
        AttachmentList[Index]["AttachmentID"] = null;
        AttachmentList[Index]["Status"] = "Active";
        this.setState({ Attachments: AttachmentList, AttachmentList: [...this.state.AttachmentList, files] });
    }

    handleDocumentDelete = (e, record) => {
        var AttachmentList = this.state.Attachments;
        var Index = AttachmentList.indexOf(record);
        AttachmentList[Index]["Status"] = "Inactive";
        this.setState({ Attachments: AttachmentList });
    }

    renderDocumentName = (cellInfo) => {

        return (
            <div className="table-input-slam">
                <CustomInput
                    inputProps={{
                        value: cellInfo.original.FileName,
                        // disabled:cellInfo.original.AttachmentPath,
                        onChange: (event) => this.handleDocumentChange(event, cellInfo)
                    }}
                />
            </div>
        )
    }

    validate = () => {
        return true;
    }


    handleSave = () => {
        if (this.validate()) {
            // console.log("paymentIssued",this.state.paymentIssued);
            // console.log("paymentList......",this.state.PaymentList);
            // console.log("paymentReceived.....",this.state.paymentReceived);
            // console.log("paymentMethod......",this.state.paymentMethod);
            let packobj = this.state.PackageList.filter(x => ((x.Status === "Active" || x.ShippingPackageDetailID !== null) && (x.EstimetedWeight !== 0 || x.EstimetedWeight !== "")));
            console.log("packobj.....",packobj);
            let scheduleobj = this.state.ShipmentType.value;
            let senderobj = this.state.FromAddress;
            let recipientobj = this.state.ToAddress;
            let commercialData = this.state.commercialList;

            let packages_data = [];
            let com_data = [];
            if (scheduleobj === "Air" || scheduleobj === "Ground") {
                if (this.state.PackageType === "Package") {
                    for (var i = 0; i < packobj.length; i++) {
                        let package_details = {};
                        package_details = {
                            shipments_tracking_number: "",
                            package_number: packobj[i].Sequence,
                            weight: packobj[i].EstimetedWeight,
                            unit_of_weight: "LBS",
                            length: packobj[i].Length,
                            width: packobj[i].Width,
                            height: packobj[i].Height,
                            chargable_weight: packobj[i].ChargableWeight,
                            insured_value: packobj[i].InsuredValue,
                            Sequence: packobj[i].Sequence,
                            PackageContent: packobj[i].PackageContent,
                            PackedType: packobj[i].PackedType,
                            Status: packobj[i].Status,
                            TV: CommonConfig.isEmpty(packobj[i].TV.data) !== true ? (packobj[i].TV.data[0] === 0 ? false : true) : packobj[i].TV,
                            Stretch: CommonConfig.isEmpty(packobj[i].Stretch.data) !== true ? (packobj[i].Stretch.data[0] === 0 ? false : true) : packobj[i].Stretch,
                            Repack: CommonConfig.isEmpty(packobj[i].Crating.data) !== true ? (packobj[i].Crating.data[0] === 0 ? false : true) : packobj[i].Crating,
                            Crating: CommonConfig.isEmpty(packobj[i].Repack.data) !== true ? (packobj[i].Repack.data[0] === 0 ? false : true) : packobj[i].Repack,
                            PackageID: packobj[i].ShippingPackageDetailID
                        }
                        packages_data.push(package_details);
                    }
                } else if (this.state.PackageType === "Envelop") {
                    let package_details = {};
                    package_details = {
                        shipments_tracking_number: "",
                        package_number: packobj[0].Sequence,
                        weight: packobj[0].EstimetedWeight,
                        unit_of_weight: "LBS",
                        length: packobj[0].Length,
                        width: packobj[0].Width,
                        height: packobj[0].Height,
                        chargable_weight: packobj[0].ChargableWeight,
                        insured_value: packobj[0].InsuredValue,
                        Sequence: packobj[0].Sequence,
                        PackedType: packobj[0].PackedType,
                        Status: packobj[0].Status,
                        PackageContent: packobj[0].PackageContent,
                        TV: CommonConfig.isEmpty(packobj[0].TV.data) !== true ? (packobj[0].TV.data[0] === 0 ? false : true) : packobj[0].TV,
                        Stretch: CommonConfig.isEmpty(packobj[0].Stretch.data) !== true ? (packobj[0].Stretch.data[0] === 0 ? false : true) : packobj[0].Stretch,
                        Repack: CommonConfig.isEmpty(packobj[0].Crating.data) !== true ? (packobj[0].Crating.data[0] === 0 ? false : true) : packobj[0].Crating,
                        Crating: CommonConfig.isEmpty(packobj[0].Repack.data) !== true ? (packobj[0].Repack.data[0] === 0 ? false : true) : packobj[0].Repack,
                        PackageID: packobj[0].ShippingPackageDetailID,
                    }

                    packages_data.push(package_details);
                }
            }
            else if (scheduleobj === "Ocean") {

                if (this.state.PackageType === "Package") {
                    for (var i = 0; i < packobj.length; i++) {
                        let package_details = {};
                        package_details = {
                            shipments_tracking_number: "",
                            package_number: packobj[i].Sequence,
                            weight: packobj[i].EstimetedWeight,
                            unit_of_weight: "LBS",
                            length: packobj[i].Length,
                            width: packobj[i].Width,
                            height: packobj[i].Height,
                            chargable_weight: packobj[i].ChargableWeight,
                            insured_value: packobj[i].InsuredValue,
                            Sequence: packobj[i].Sequence,
                            Status: packobj[i].Status,
                            TV: CommonConfig.isEmpty(packobj[i].TV.data) !== true ? (packobj[i].TV.data[0] === 0 ? false : true) : packobj[i].TV,
                            Stretch: CommonConfig.isEmpty(packobj[i].Stretch.data) !== true ? (packobj[i].Stretch.data[0] === 0 ? false : true) : packobj[i].Stretch,
                            Repack: CommonConfig.isEmpty(packobj[i].Crating.data) !== true ? (packobj[i].Crating.data[0] === 0 ? false : true) : packobj[i].Crating,
                            Crating: CommonConfig.isEmpty(packobj[i].Repack.data) !== true ? (packobj[i].Repack.data[0] === 0 ? false : true) : packobj[i].Repack,
                            PackageContent: packobj[i].PackageContent,
                            PackedType: packobj[i].PackedType,
                            CFT: packobj[i].CFT,
                            PackageID: packobj[i].ShippingPackageDetailID
                        }
                        packages_data.push(package_details);
                    }
                } else if (this.state.PackageType === "Envelop") {
                    let package_details = {};
                    package_details = {
                        shipments_tracking_number: "",
                        package_number: packobj[0].Sequence,
                        weight: packobj[0].EstimetedWeight,
                        unit_of_weight: "LBS",
                        length: packobj[0].Length,
                        width: packobj[0].Width,
                        height: packobj[0].Height,
                        chargable_weight: packobj[0].ChargableWeight,
                        insured_value: packobj[0].InsuredValue,
                        Sequence: packobj[0].Sequence,
                        Status: packobj[0].Status,
                        TV: CommonConfig.isEmpty(packobj[0].TV.data) !== true ? (packobj[0].TV.data[0] === 0 ? false : true) : packobj[0].TV,
                        Stretch: CommonConfig.isEmpty(packobj[0].Stretch.data) !== true ? (packobj[0].Stretch.data[0] === 0 ? false : true) : packobj[0].Stretch,
                        Repack: CommonConfig.isEmpty(packobj[0].Crating.data) !== true ? (packobj[0].Crating.data[0] === 0 ? false : true) : packobj[0].Crating,
                        Crating: CommonConfig.isEmpty(packobj[0].Repack.data) !== true ? (packobj[0].Repack.data[0] === 0 ? false : true) : packobj[0].Repack,
                        PackageContent: packobj[0].PackageContent,
                        PackedType: packobj[0].PackedType,
                        CFT: packobj[0].CFT,
                        is_active: 1,
                        is_deleted: 0,
                        PackageID: packobj[0].ShippingPackageDetailID,
                    }

                    packages_data.push(package_details);
                }
            }

            var packages = packages_data;

            if (scheduleobj !== "Ocean") {
                for (var i = 0; i < commercialData.length; i++) {
                    let commercail_details = {};
                    commercail_details = {
                        shipments_tracking_number: "",
                        package_number: commercialData[i].PackageNumber,
                        content_description: commercialData[i].ContentDescription,
                        quantity: commercialData[i].Quantity,
                        value_per_qty: commercialData[i].ValuePerQuantity,
                        total_value: commercialData[i].TotalValue,
                        Status: commercialData[i].Status,
                        CommercialInvoiceID: commercialData[i].ShippingCommercialInvoiceID
                    }
                    com_data.push(commercail_details);
                }
            }
            var commercial = com_data


            var shipments = {
                tracking_number: '',
                shipment_type: scheduleobj,
                location_type: recipientobj.LocationType,
                is_pickup: senderobj.IsPickup.data[0] === 0 ? false : true,
                ShipmentStatus: 'Pickup Scheduled',
                pickup_date: CommonConfig.isEmpty(senderobj.PickupDate) != true ? moment(senderobj.PickupDate).format("YYYY-MM-DD HH:mm:ss").toString() : null,
                package_type: !CommonConfig.isEmpty(packobj) ? this.state.PackageType : '',
                total_packages: packobj.length,
                // is_pay_online: this.state.payOnline,
                // is_pay_bank: this.state.payBank,
                promo_code: '',
                is_agree: '',
                total_weight: !CommonConfig.isEmpty(senderobj) ? senderobj.TotalWeight : 0,
                total_chargable_weight: !CommonConfig.isEmpty(senderobj) ? senderobj.TotalChargableWeight : 0,
                total_insured_value: !CommonConfig.isEmpty(senderobj) ? senderobj.TotalInsuredValue : 0,
                duties_paid_by: !CommonConfig.isEmpty(senderobj) ? senderobj.DutiesPaidBy : '',
                total_declared_value: !CommonConfig.isEmpty(senderobj) ? senderobj.TotalDeclaredValue : 0,
                // dutyType: this.state.dutyType,
                userName: CommonConfig.loggedInUserData().LoginID,
                managed_by: this.state.ManagedBy.value,
                ServiceName: this.state.ServiceName.value,
                SubServiceName: this.state.SubServiceName.value,
                ShippingID: this.props.history.location.state.ShipppingID
            }

            var from_address = {
                AddressID: senderobj.FromAddressID,
                country_id: this.state.selectedFromCountry.value,
                country_name: this.state.selectedFromCountry.label,
                company_name: senderobj.CompanyName,
                contact_name: senderobj.ContactName,
                address_1: senderobj.AddressLine1,
                address_2: senderobj.AddressLine2,
                address_3: senderobj.AddressLine3,
                MovingBack: CommonConfig.isEmpty(this.state.FromMovingBack.value) ? this.state.FromMovingBack : this.state.FromMovingBack.value,
                OriginalPassportAvailable: CommonConfig.isEmpty(this.state.FromOriginalPassortAvailable.value) ? this.state.FromOriginalPassortAvailable : this.state.FromOriginalPassortAvailable.value,
                EligibleForTR: CommonConfig.isEmpty(this.state.FromEligibleForTR.value) ? this.state.FromEligibleForTR : this.state.FromEligibleForTR.value,
                city_id: 1,
                city_name: CommonConfig.isEmpty(this.state.fromCity.value) ? this.state.fromCity : this.state.fromCity.value,
                state_id: 1,
                state_name: CommonConfig.isEmpty(this.state.fromState.value) ? this.state.fromState : this.state.fromState.value,
                zip_code: senderobj.ZipCode,
                phone1: senderobj.Phone1,
                phone2: senderobj.Phone2,
                email: senderobj.Email,
                is_active: 1,
                is_deleted: 0
            }


            var to_address = {
                AddressID: recipientobj.ToAddressID,
                country_id: this.state.selectedToCountry.value,
                country_name: this.state.selectedToCountry.label,
                company_name: recipientobj.CompanyName,
                contact_name: recipientobj.ContactName,
                address_1: recipientobj.AddressLine1,
                address_2: recipientobj.AddressLine2,
                address_3: recipientobj.AddressLine3,
                city_id: 2,
                city_name: CommonConfig.isEmpty(this.state.toCity.value) ? this.state.toCity : this.state.toCity.value,
                state_id: 1,
                state_name: CommonConfig.isEmpty(this.state.toState.value) ? this.state.toState : this.state.toState.value,
                zip_code: recipientobj.ZipCode,
                phone1: recipientobj.Phone1,
                phone2: recipientobj.Phone2,
                email: recipientobj.Email,
                is_active: 1,
                is_deleted: 0
            }

            let paymentObj = this.state.paymentMethod;
            var payment_online = {
                PaymentID: paymentObj[0]["PaymentID"],
                PaymentType: paymentObj[0]["PaymentType"],
                name_on_card: paymentObj[0]["CardName"],
                card_number: paymentObj[0]["CardNumber"],
                card_type: paymentObj[0]["CardType"],
                expiration_month: this.state.month_value,
                expiration_year: this.state.year_value,
                cvv_code: this.state.Cvv,
                zip_code: this.state.BillingZipCode,
                is_active: 1,
                is_deleted: 0
            }


            var payment_bank = {
                name_on_bank_account: this.state.NameOnBankAccount,
                bank_name: this.state.BankName,
                account_number: this.state.BankAccountNumber,
                routing_number: this.state.ABAroutingNumber,
                is_active: 1,
                is_deleted: 0
            }

            var FinalNotes = this.state.notes.filter(x => (x.NoteText !== '' && x.NoteText !== null));
            let objdata = {
                UserID: CommonConfig.loggedInUserData().PersonID,
                TrackingNumber: this.state.TrackingNumber,
                shipments: shipments,
                from_address: from_address,
                to_address: to_address,
                payment_online: payment_online,
                payment_bank: payment_bank,
                paymentType: paymentObj[0]["PaymentType"],
                packages: packages,
                commercial: commercial,
                Notes: FinalNotes,
                TotalCommercialvalue: ''
            }

            this.showLoader();

            try {
                api.post('scheduleshipment/addshipments', objdata).then(res => {
                    if (res.success) {
                        cogoToast.success("Updated Successfully");
                        const { history } = this.props;
                        // // localStorage.setItem('shipmentObj', JSON.stringify(shipmentdata));
                        history.push('/admin/ShipmentList');
                    }
                    else {
                        // this.hideLoader();
                        console.log("Schedule Shipment is Not Created in else")
                        cogoToast.error("Schedule Shipment is Not Created!");

                    }
                }).catch(err => {
                    console.log("error...", err);
                })

            }
            catch (err) {
                console.log("error..", err);
            }
        }
    }






    render() {
        const { TrackingNumber, ManagedBy, CreatedBy, ServiceName, PackageType, TotalPackages,
            SubServiceName, Subservicename, ShipmentDate, ShipmentType, Steps, selectedFromCountry,
            selectedToCountry, FromAddress, ToAddress, YesNo, fromState, fromCity, toCity, toState,
            FromMovingBack, FromEligibleForTR, FromOriginalPassortAvailable } = this.state;
        const shipmentType = this.state.shipmentTypeList.map(type => { return { value: type.Description, label: type.Description } });
        const managedBy = this.state.managedByList.map(type => { return { value: type.UserID, label: type.Name } });
        const serviceName = this.state.ServiceList.map(type => { return { value: type.MainServiceName, label: type.MainServiceName } });
        const subServiceName = this.state.SubServiceList.map(type => { return { value: type.ServiceName, label: type.ServiceName } });
        const CountryOption = this.state.CountryList.map(Country => { return { value: Country.CountryID, label: Country.CountryName } });
        const fromCityOptions = this.state.fromGoogleAPICityList.map(city => { return { value: city.City_code, label: city.Name } });
        const fromStateOptions = this.state.fromStateList.map(state => { return { value: state.StateName, label: state.StateName } });
        const toCityOptions = this.state.toGoogleAPICityList.map(city => { return { value: city.City_code, label: city.Name } });
        const toStateOptions = this.state.toStateList.map(state => { return { value: state.StateName, label: state.StateName } });
        const columns = [
            {

                Header: "Document Name",
                accessor: "Name",
                width: 220,
                maxWidth: 220,
                Cell: this.renderDocumentName
            },
            {
                Header: "CreatedOn",
                accessor: "DocumentCreatedOn",
                width: 220,
                maxWidth: 220
            },
            {
                Header: "Added By",
                accessor: "DocumentCreatedBy",
                width: 280,
                maxWidth: 280
            },
            {
                Header: "Attachment",
                accessor: "actions",
                width: 80,
                filterable: false,
                sortable: false,
                Cell: record => {
                    return (
                        <div>
                            View File
                        </div>
                    );
                },
            },
            {
                width: 100,
                filterable: false,
                sortable: false,
                Header: "Actions",
                Cell: record => {
                    return (
                        record.original.AttachmentPath ?

                            <div className="align-right">

                                {this.state.Access.DeleteAccess === 1 ?
                                    <Button justIcon color="danger" className="Plus-btn" onClick={(e) => this.handleDocumentDelete(e, record.original)}>
                                        <i className={"fas fa-minus"} />
                                    </Button>
                                    : null
                                }
                            </div>
                            :
                            this.state.Attachments.filter(x => x.Status === "Active").length === record.index + 1 ?

                                <div className="align-right">
                                    <Button justIcon color="facebook" onClick={() => this.AddNewRowData()} className="Plus-btn ">
                                        <i className={"fas fa-plus"} />
                                    </Button>
                                </div>
                                :
                                null
                    )
                }
            }
        ]


        return (
            <div>
                {this.state.Loading === true ?
                    <div className="loading">
                        <SimpleBackdrop />
                    </div>
                    : null}
                <GridContainer justify="center" className="schedule-pickup-main-outer">
                    <GridItem xs={12} sm={12}>
                        <Card>
                            <CardHeader className="btn-right-outer" color="primary" icon>
                                <CardIcon color="primary">
                                    <FlightTakeoff />
                                </CardIcon>
                                <h4 className="margin-right-auto text-color-black">Shipment Information</h4>
                            </CardHeader>
                            <CardBody>
                                <GridContainer>
                                    <GridItem xs={12} sm={4} md={3}>
                                        <CustomInput
                                            labelText="Tracking Number"
                                            id="trackingnumber"
                                            formControlProps={{
                                                fullWidth: true
                                            }}
                                            inputProps={{
                                                disabled: true,
                                                value: TrackingNumber,
                                                endAdornment: (
                                                    <InputAdornment position="end" className={classes.inputAdornment}>
                                                        <Icon className={classes.User}>
                                                            format_list_numbered
                                                            </Icon>
                                                    </InputAdornment>
                                                )
                                            }}
                                        />
                                    </GridItem>
                                    <GridItem xs={12} sm={4} md={3}>
                                        <CustomInput
                                            labelText="Username"
                                            id="proposaltype"
                                            formControlProps={{
                                                fullWidth: true
                                            }}
                                            inputProps={{
                                                disabled: true,
                                                value: CreatedBy,
                                                endAdornment: (
                                                    <InputAdornment position="end" className={classes.inputAdornment}>
                                                        <Icon className={classes.User}>
                                                            person
                                                        </Icon>
                                                    </InputAdornment>
                                                )
                                            }}
                                        />
                                    </GridItem>
                                    <GridItem xs={12} sm={4} md={3}>
                                        <CustomInput
                                            labelText="Ship Date"
                                            id="proposaltype"
                                            formControlProps={{
                                                fullWidth: true
                                            }}
                                            inputProps={{
                                                disabled: true,
                                                value: moment(ShipmentDate).format(CommonConfig.dateFormat.dateOnly),
                                                endAdornment: (
                                                    <InputAdornment position="end" className={classes.inputAdornment}>
                                                        <Icon className={classes.User}>
                                                            person
                                                        </Icon>
                                                    </InputAdornment>
                                                )
                                            }}
                                        />
                                    </GridItem>
                                </GridContainer>
                                <GridContainer>
                                    <GridItem xs={12} sm={3} md={3}>
                                        <Autocomplete
                                            id="combo-box-demo"
                                            options={managedBy}
                                            value={ManagedBy}
                                            onChange={(event, value) => this.selectChange(event, value, "ManagedBy")}
                                            getOptionLabel={(option) => option.label}
                                            renderInput={(params) => <TextField {...params} label="Managed By" />}
                                        />
                                    </GridItem>
                                    <GridItem xs={12} sm={3} md={3}>
                                        <Autocomplete
                                            id="combo-box-demo"
                                            options={shipmentType}
                                            value={ShipmentType}
                                            onChange={(event, value) => this.selectChange(event, value, "ShipmentType")}
                                            getOptionLabel={(option) => option.label}
                                            renderInput={(params) => <TextField {...params} label="Shipment Type" />}
                                        />
                                    </GridItem>
                                    <GridItem xs={12} sm={3} md={3}>
                                        <Autocomplete
                                            id="combo-box-demo"
                                            options={serviceName}
                                            value={ServiceName}
                                            onChange={(event, value) => this.selectChange(event, value, "ServiceType")}
                                            getOptionLabel={(option) => option.label}
                                            renderInput={(params) => <TextField {...params} label="Service Type" />}
                                        >
                                        </Autocomplete>
                                    </GridItem>
                                    <GridItem xs={12} sm={3} md={3}>
                                        <Autocomplete
                                            id="combo-box-demo"
                                            disabled={Subservicename}
                                            value={SubServiceName}
                                            options={subServiceName}
                                            onChange={(event, value) => this.selectChange(event, value, "SubServiceType")}
                                            getOptionLabel={(option) => option.label}
                                            renderInput={(params) => <TextField {...params} label="Sub Service Type" />}
                                        />
                                    </GridItem>
                                </GridContainer>
                            </CardBody>
                        </Card>
                    </GridItem>
                </GridContainer>
                <GridContainer justify="center" className="schedule-pickup-main-outer">
                    <GridItem xs={12} sm={12}>
                        <Card>
                            <CardHeader className="btn-right-outer" color="primary" icon>
                                <CardIcon color="primary">
                                    <FlightTakeoff />
                                </CardIcon>
                                <h4 className="margin-right-auto text-color-black">Shipment</h4>
                            </CardHeader>
                            <div className="shipment-nav">
                                <ul>
                                    {Steps.map((step, key) => {
                                        return (
                                            <li>
                                                <a className={step.classname} href="#"
                                                    onClick={e => {
                                                        e.preventDefault();
                                                        this.navigateChange(key);
                                                    }}>
                                                    <span>{step.stepName}</span>
                                                </a>
                                            </li>
                                        )
                                    })
                                    }
                                </ul>
                            </div>
                            <div className="shipment-content">
                                <div className="shipment-pane" id="customerdetails">

                                    <GridContainer>
                                        <GridItem xs={12} sm={12} md={4}>
                                            <h4>Sender Information</h4>
                                        </GridItem>
                                    </GridContainer>
                                    <GridContainer className="MuiGrid-justify-xs-center">
                                        <GridItem xs={12} sm={12} md={3}>
                                            <CustomInput
                                                labelText="Contact Name"
                                                id="proposaltype"
                                                formControlProps={{
                                                    fullWidth: true
                                                }}
                                                inputProps={{
                                                    value: FromAddress.ContactName,
                                                    onChange: event => this.handleChangeFrom(event, "contactname"),
                                                    endAdornment: (
                                                        <InputAdornment position="end" className={classes.inputAdornment}>
                                                            <Icon className={classes.User}>
                                                                perm_identity
                                                            </Icon>
                                                        </InputAdornment>
                                                    )
                                                }}
                                            />
                                        </GridItem>
                                        <GridItem xs={12} sm={12} md={3}>
                                            <CustomInput
                                                labelText="Address Line 1"
                                                id="proposaltype"
                                                formControlProps={{
                                                    fullWidth: true
                                                }}
                                                inputProps={{
                                                    value: FromAddress.AddressLine1,
                                                    onChange: event => this.handleChangeFrom(event, "address1"),
                                                    endAdornment: (
                                                        <InputAdornment position="end" className={classes.inputAdornment}>
                                                            <Icon className={classes.User}>
                                                                location_on
                                                            </Icon>
                                                        </InputAdornment>
                                                    )
                                                }}
                                            />
                                        </GridItem>
                                        <GridItem xs={12} sm={12} md={3}>
                                            <CustomInput
                                                labelText="Address Line 2"
                                                id="proposaltype"
                                                formControlProps={{
                                                    fullWidth: true
                                                }}
                                                inputProps={{
                                                    value: FromAddress.AddressLine2,
                                                    onChange: event => this.handleChangeFrom(event, "address2"),
                                                    endAdornment: (
                                                        <InputAdornment position="end" className={classes.inputAdornment}>
                                                            <Icon className={classes.User}>
                                                                location_on
                                                            </Icon>
                                                        </InputAdornment>
                                                    )
                                                }}
                                            />
                                        </GridItem>
                                        <GridItem xs={12} sm={12} md={3}>
                                            <CustomInput
                                                labelText="Address Line 3"
                                                id="proposaltype"
                                                formControlProps={{
                                                    fullWidth: true
                                                }}
                                                inputProps={{
                                                    value: FromAddress.AddressLine3,
                                                    onChange: event => this.handleChangeFrom(event, "address3"),
                                                    endAdornment: (
                                                        <InputAdornment position="end" className={classes.inputAdornment}>
                                                            <Icon className={classes.User}>
                                                                language
                                                            </Icon>
                                                        </InputAdornment>
                                                    )
                                                }}
                                            />
                                        </GridItem>

                                    </GridContainer>

                                    <GridContainer className="MuiGrid-justify-xs-center">
                                        <GridItem xs={12} sm={12} md={3}>
                                            <FormControl fullWidth>
                                                <Autocomplete
                                                    options={CountryOption}
                                                    id="FromCountry"
                                                    getOptionLabel={option => option.label ? option.label : option}
                                                    value={selectedFromCountry}
                                                    autoSelect
                                                    onChange={(event, value) => this.selectChangeTab1(event, value, "FromCountry")}
                                                    renderInput={params => (
                                                        <TextField {...params} error={this.state.pickupcountryErr} helperText={this.state.pickupcountryHelperText}
                                                            label="From Country" margin="normal" fullWidth />)} />
                                            </FormControl>
                                        </GridItem>
                                        <GridItem xs={12} sm={12} md={3}>
                                            <CustomInput
                                                labelText="Zip"
                                                id="proposaltype"
                                                formControlProps={{
                                                    fullWidth: true
                                                }}
                                                inputProps={{
                                                    value: FromAddress.ZipCode,
                                                    onChange: event => this.handleChangeFrom(event, "zip"),
                                                    onBlur: event => this.handleBlur(event, "FromZipCode"),
                                                    endAdornment: (
                                                        <InputAdornment position="end" className={classes.inputAdornment}>
                                                            <Icon className={classes.User}>
                                                                local_post_office
                                                            </Icon>
                                                        </InputAdornment>
                                                    )
                                                }}
                                            />
                                        </GridItem>
                                        <GridItem xs={12} sm={12} md={3}>
                                            {this.state.fromCityAutoComplete === false ? (
                                                <CustomInput
                                                    labelText="City"
                                                    id="city"
                                                    // error={fromCityErr}
                                                    // helperText={fromCityHelperText}
                                                    formControlProps={{ fullWidth: true }}
                                                    inputProps={{
                                                        value: fromCity,
                                                        onBlur: (event) => this.handleBlur(event, "fromcity"),
                                                        onChange: (event) => this.handleChange(event, "fromcity"),
                                                        onFocus: () => this.setState({ fromCityErr: false, fromCityHelperText: "" }),
                                                        endAdornment: (
                                                            <InputAdornment position="end" className={classes.inputAdornment}>
                                                                <Icon>location_city</Icon></InputAdornment>)
                                                    }}
                                                />
                                            ) : (
                                                    <Autocomplete
                                                        options={fromCityOptions}
                                                        id="fromcity"
                                                        autoSelect
                                                        getOptionLabel={option => option.label}
                                                        value={fromCity}
                                                        onChange={(event, value) => this.ChangeFromCity(event, value)}
                                                        renderInput={params => (
                                                            <TextField {...params} margin="normal" label="City" fullWidth />)}
                                                    />)
                                            }
                                            {/* <CustomInput
                                                labelText="City"
                                                id="proposaltype"
                                                formControlProps={{
                                                    fullWidth: true
                                                }}
                                                inputProps={{
                                                    value:FromAddress.City,
                                                onChange: event => this.handleChangeFrom(event,"city"),
                                                    endAdornment: (
                                                        <InputAdornment position="end" className={classes.inputAdornment}>
                                                            <Icon className={classes.User}>
                                                                location_city
                                                            </Icon>
                                                        </InputAdornment>
                                                    )
                                                }}
                                            /> */}
                                        </GridItem>
                                        <GridItem xs={12} sm={12} md={3}>

                                            {this.state.fromStateAutoComplete === false ? (
                                                <CustomInput
                                                    labelText="State"
                                                    id="state"
                                                    // error={fromStateErr}
                                                    // helperText={fromStateHelperText}
                                                    formControlProps={{ fullWidth: true }}
                                                    inputProps={{
                                                        value: fromState,
                                                        onBlur: (event) => this.handleBlur(event, "fromstate"),
                                                        onChange: (event) => this.handleChange(event, "fromstate"),
                                                        onFocus: () => this.setState({ fromStateErr: false, fromStateHelperText: "" }),
                                                        endAdornment: (
                                                            <InputAdornment position="end" className={classes.inputAdornment}>
                                                                <Icon>location_city</Icon></InputAdornment>)
                                                    }}
                                                />
                                            ) : (
                                                    <Autocomplete
                                                        options={fromStateOptions}
                                                        id="fromState"
                                                        autoSelect
                                                        getOptionLabel={option => option.label}
                                                        value={fromState}
                                                        onChange={(event, value) => this.ChangeFromState(event, value)}
                                                        renderInput={params => (
                                                            <TextField {...params} margin="normal" label="State" fullWidth />)}
                                                    />)
                                            }
                                            {/* <CustomInput
                                                labelText="State"
                                                id="proposaltype"
                                                formControlProps={{
                                                    fullWidth: true
                                                }}
                                                inputProps={{
                                                    value:FromAddress.State,
                                                    onChange: event => this.handleChangeFrom(event,"state"),
                                                    endAdornment: (
                                                        <InputAdornment position="end" className={classes.inputAdornment}>
                                                            <Icon className={classes.User}>
                                                                map
                                                            </Icon>
                                                        </InputAdornment>
                                                    )
                                                }}
                                            /> */}
                                        </GridItem>

                                    </GridContainer>
                                    <GridContainer >
                                        <GridItem xs={12} sm={12} md={3}>
                                            <CustomInput
                                                labelText="Company Name"
                                                id="proposaltype"
                                                formControlProps={{
                                                    fullWidth: true
                                                }}
                                                inputProps={{
                                                    value: FromAddress.CompanyName,
                                                    onChange: event => this.handleChangeFrom(event, "companyname"),
                                                    endAdornment: (
                                                        <InputAdornment position="end" className={classes.inputAdornment}>
                                                            <Icon className={classes.User}>
                                                                assignment_ind
                                                            </Icon>
                                                        </InputAdornment>
                                                    )
                                                }}
                                            />
                                        </GridItem>
                                        <GridItem xs={12} sm={12} md={3}>
                                            <CustomInput
                                                labelText="Phone 1"
                                                id="proposaltype"
                                                formControlProps={{
                                                    fullWidth: true
                                                }}
                                                inputProps={{
                                                    value: FromAddress.Phone1,
                                                    onChange: event => this.handleChangeFrom(event, "phone1"),
                                                    endAdornment: (
                                                        <InputAdornment position="end" className={classes.inputAdornment}>
                                                            <Icon className={classes.User}>
                                                                call
                                                            </Icon>
                                                        </InputAdornment>
                                                    )
                                                }}
                                            />
                                        </GridItem>
                                        <GridItem xs={12} sm={12} md={3}>
                                            <CustomInput
                                                labelText="Phone 2"
                                                id="proposaltype"
                                                formControlProps={{
                                                    fullWidth: true
                                                }}
                                                inputProps={{
                                                    value: FromAddress.Phone2,
                                                    onChange: event => this.handleChangeFrom(event, "phone2"),
                                                    endAdornment: (
                                                        <InputAdornment position="end" className={classes.inputAdornment}>
                                                            <Icon className={classes.User}>
                                                                call
                                                            </Icon>
                                                        </InputAdornment>
                                                    )
                                                }}
                                            />
                                        </GridItem>
                                        <GridItem xs={12} sm={12} md={3}>
                                            <CustomInput
                                                labelText="Email"
                                                id="registeremail"
                                                formControlProps={{
                                                    fullWidth: true
                                                }}
                                                inputProps={{
                                                    value: FromAddress.Email,
                                                    onChange: event => this.handleChangeFrom(event, "email"),
                                                    endAdornment: (
                                                        <InputAdornment position="end" className={classes.inputAdornment}>
                                                            <Icon className={classes.inputAdornmentIcon}>
                                                                email
                                                            </Icon>
                                                        </InputAdornment>
                                                    )
                                                }}
                                            />
                                        </GridItem>
                                    </GridContainer>
                                    {this.state.ShipmentType.value === "Ocean" ?
                                        <GridContainer className="MuiGrid-justify-xs-center">
                                            <GridItem xs={12} sm={12} md={3}>
                                                <FormControl fullWidth>
                                                    <Autocomplete
                                                        options={YesNo}
                                                        id="FromCountry"
                                                        getOptionLabel={option => option.label ? option.label : option}
                                                        value={FromMovingBack}
                                                        autoSelect
                                                        onChange={(event, value) => this.selectChangeTab1(event, value, "MovingBack")}
                                                        renderInput={params => (
                                                            <TextField {...params} error={this.state.pickupcountryErr} helperText={this.state.pickupcountryHelperText}
                                                                label="Moving Back ?" margin="normal" fullWidth />)} />
                                                </FormControl>

                                            </GridItem>
                                            <GridItem xs={12} sm={12} md={3}>
                                                <FormControl fullWidth>
                                                    <Autocomplete
                                                        options={YesNo}
                                                        id="FromCountry"
                                                        getOptionLabel={option => option.label ? option.label : option}
                                                        value={FromOriginalPassortAvailable}
                                                        autoSelect
                                                        onChange={(event, value) => this.selectChangeTab1(event, value, "PassportAvailable")}
                                                        renderInput={params => (
                                                            <TextField {...params} error={this.state.pickupcountryErr} helperText={this.state.pickupcountryHelperText}
                                                                label="Original Passport Avaliable ?" margin="normal" fullWidth />)} />
                                                </FormControl>

                                            </GridItem>
                                            <GridItem xs={12} sm={12} md={3}>
                                                <FormControl fullWidth>
                                                    <Autocomplete
                                                        options={YesNo}
                                                        id="FromCountry"
                                                        getOptionLabel={option => option.label ? option.label : option}
                                                        value={FromEligibleForTR}
                                                        autoSelect
                                                        onChange={(event, value) => this.selectChangeTab1(event, value, "EligibleTR")}
                                                        renderInput={params => (
                                                            <TextField {...params} error={this.state.pickupcountryErr} helperText={this.state.pickupcountryHelperText}
                                                                label="Eligible for TR ?" margin="normal" fullWidth />)} />
                                                </FormControl>
                                            </GridItem>
                                            <GridItem xs={12} sm={12} md={3}>
                                            {/* <CustomInput /> */}
                                            </GridItem>
                                        </GridContainer>
                                        : null}
                                    <GridContainer className="mt-20">
                                        <GridItem xs={12} sm={12} md={4}>
                                            <h4>Receipent Details</h4>
                                        </GridItem>
                                    </GridContainer>
                                    <GridContainer className="MuiGrid-justify-xs-center">
                                        <GridItem xs={12} sm={12} md={3}>
                                            <CustomInput
                                                labelText="Contact Name"
                                                id="proposaltype"
                                                formControlProps={{
                                                    fullWidth: true
                                                }}
                                                inputProps={{
                                                    value: ToAddress.ContactName,
                                                    onChange: event => this.handleChangeTo(event, "contactname"),
                                                    endAdornment: (
                                                        <InputAdornment position="end" className={classes.inputAdornment}>
                                                            <Icon className={classes.User}>
                                                                perm_identity
                                                            </Icon>
                                                        </InputAdornment>
                                                    )
                                                }}
                                            />
                                        </GridItem>
                                        <GridItem xs={12} sm={12} md={3}>
                                            <CustomInput
                                                labelText="Address Line 1"
                                                id="proposaltype"
                                                formControlProps={{
                                                    fullWidth: true
                                                }}
                                                inputProps={{
                                                    value: ToAddress.AddressLine1,
                                                    onChange: event => this.handleChangeTo(event, "address1"),
                                                    endAdornment: (
                                                        <InputAdornment position="end" className={classes.inputAdornment}>
                                                            <Icon className={classes.User}>
                                                                location_on
                                                            </Icon>
                                                        </InputAdornment>
                                                    )
                                                }}
                                            />
                                        </GridItem>
                                        <GridItem xs={12} sm={12} md={3}>
                                            <CustomInput
                                                labelText="Address Line 2"
                                                id="proposaltype"
                                                formControlProps={{
                                                    fullWidth: true
                                                }}
                                                inputProps={{
                                                    value: ToAddress.AddressLine2,
                                                    onChange: event => this.handleChangeTo(event, "address2"),
                                                    endAdornment: (
                                                        <InputAdornment position="end" className={classes.inputAdornment}>
                                                            <Icon className={classes.User}>
                                                                location_on
                                                            </Icon>
                                                        </InputAdornment>
                                                    )
                                                }}
                                            />
                                        </GridItem>
                                        <GridItem xs={12} sm={12} md={3}>
                                            <CustomInput
                                                labelText="Address Line 3"
                                                id="proposaltype"
                                                formControlProps={{
                                                    fullWidth: true
                                                }}
                                                inputProps={{
                                                    value: ToAddress.AddressLine3,
                                                    onChange: event => this.handleChangeTo(event, "address3"),
                                                    endAdornment: (
                                                        <InputAdornment position="end" className={classes.inputAdornment}>
                                                            <Icon className={classes.User}>
                                                                language
                                                            </Icon>
                                                        </InputAdornment>
                                                    )
                                                }}
                                            />
                                        </GridItem>

                                    </GridContainer>
                                    <GridContainer className="MuiGrid-justify-xs-center">
                                        <GridItem xs={12} sm={12} md={3}>
                                            <FormControl fullWidth>
                                                <Autocomplete
                                                    options={CountryOption}
                                                    id="ToCountry"
                                                    getOptionLabel={option => option.label ? option.label : option}
                                                    value={selectedToCountry}
                                                    autoSelect
                                                    onChange={(event, value) => this.selectChangeTab1(event, value, "ToCountry")}
                                                    renderInput={params => (
                                                        <TextField {...params} error={this.state.pickupcountryErr} helperText={this.state.pickupcountryHelperText}
                                                            label="To Country" margin="normal" fullWidth />)} />
                                            </FormControl>

                                        </GridItem>
                                        <GridItem xs={12} sm={12} md={3}>
                                            <CustomInput
                                                labelText="Zip"
                                                id="proposaltype"
                                                formControlProps={{
                                                    fullWidth: true
                                                }}
                                                inputProps={{
                                                    value: ToAddress.ZipCode,
                                                    onChange: event => this.handleChangeTo(event, "zip"),
                                                    onBlur: event => this.handleBlur(event, "ToZipCode"),
                                                    endAdornment: (
                                                        <InputAdornment position="end" className={classes.inputAdornment}>
                                                            <Icon className={classes.User}>
                                                                local_post_office
                                                            </Icon>
                                                        </InputAdornment>
                                                    )
                                                }}
                                            />
                                        </GridItem>
                                        <GridItem xs={12} sm={12} md={3}>
                                            {this.state.toCityAutoComplete === false ? (
                                                <CustomInput
                                                    labelText="City"
                                                    id="city"
                                                    // error={toCityErr}
                                                    // helperText={toCityHelperText}
                                                    formControlProps={{ fullWidth: true }}
                                                    inputProps={{
                                                        value: toCity,
                                                        onBlur: event => this.handleBlur(event, "tocity"),
                                                        onChange: event => this.handleChange(event, "tocity"),
                                                        onFocus: event => this.setState({ toCityErr: false, toCityHelperText: "" }),
                                                        endAdornment: (<InputAdornment position="end" className={classes.inputAdornment}>
                                                            <Icon>location_city</Icon></InputAdornment>)
                                                    }}
                                                />
                                            ) : (
                                                    <Autocomplete
                                                        options={toCityOptions}
                                                        id="tocity"
                                                        autoSelect
                                                        getOptionLabel={option => option.label}
                                                        value={toCity}
                                                        onChange={(event, value) => this.ChangeToCity(event, value)}
                                                        renderInput={params => (
                                                            <TextField {...params} margin="normal" label="City" fullWidth />)}
                                                    />
                                                )}
                                            {/* <CustomInput
                                                labelText="City"
                                                id="proposaltype"
                                                formControlProps={{
                                                    fullWidth: true
                                                }}
                                                inputProps={{
                                                    value:ToAddress.City,
                                                    onChange: event => this.handleChangeTo(event,"city"),
                                                    endAdornment: (
                                                        <InputAdornment position="end"  className={classes.inputAdornment}>
                                                            <Icon className={classes.User}>
                                                                location_city
                                                            </Icon>
                                                        </InputAdornment>
                                                    )
                                                }}
                                            /> */}
                                        </GridItem>
                                        <GridItem xs={12} sm={12} md={3}>
                                            {this.state.toStateAutoComplete === false ? (
                                                <CustomInput
                                                    labelText="State"
                                                    id="state"
                                                    // error={toStateErr}
                                                    // helperText={toStateHelperText}
                                                    formControlProps={{ fullWidth: true }}
                                                    inputProps={{
                                                        value: toState,
                                                        onBlur: event => this.handleBlur(event, "tostate"),
                                                        onChange: event => this.handleChange(event, "tostate"),
                                                        onFocus: event => this.setState({ toStateErr: false, toStateHelperText: "" }),
                                                        endAdornment: (<InputAdornment position="end" className={classes.inputAdornment}>
                                                            <Icon>location_city</Icon></InputAdornment>)
                                                    }}
                                                />
                                            ) : (
                                                    <Autocomplete
                                                        options={toStateOptions}
                                                        id="toState"
                                                        autoSelect
                                                        getOptionLabel={option => option.label}
                                                        value={toState}
                                                        onChange={(event, value) => this.ChangeToState(event, value)}
                                                        renderInput={params => (
                                                            <TextField {...params} margin="normal" label="State" fullWidth />)}
                                                    />
                                                )}
                                            {/* <CustomInput
                                                labelText="State"
                                                id="proposaltype"
                                                formControlProps={{
                                                    fullWidth: true
                                                }}
                                                inputProps={{
                                                    value:ToAddress.State,
                                                    onChange: event => this.handleChangeTo(event,"state"),
                                                    endAdornment: (
                                                        <InputAdornment  position="end" className={classes.inputAdornment}>
                                                            <Icon className={classes.User}>
                                                                map
                                                            </Icon>
                                                        </InputAdornment>
                                                    )
                                                }}
                                            /> */}
                                        </GridItem>

                                    </GridContainer>
                                    <GridContainer >
                                        <GridItem xs={12} sm={12} md={3}>
                                            <CustomInput
                                                labelText="Company Name"
                                                id="proposaltype"
                                                formControlProps={{
                                                    fullWidth: true
                                                }}
                                                inputProps={{
                                                    value: ToAddress.CompanyName,
                                                    onChange: event => this.handleChangeTo(event, "companyname"),
                                                    endAdornment: (
                                                        <InputAdornment position="end" className={classes.inputAdornment}>
                                                            <Icon className={classes.User}>
                                                                assignment_ind
                                                            </Icon>
                                                        </InputAdornment>
                                                    )
                                                }}
                                            />
                                        </GridItem>
                                        <GridItem xs={12} sm={12} md={3}>
                                            <CustomInput
                                                labelText="Phone 1"
                                                id="proposaltype"
                                                formControlProps={{
                                                    fullWidth: true
                                                }}
                                                inputProps={{
                                                    value: ToAddress.Phone1,
                                                    onChange: event => this.handleChangeTo(event, "phone1"),
                                                    endAdornment: (
                                                        <InputAdornment position="end" className={classes.inputAdornment}>
                                                            <Icon className={classes.User}>
                                                                call
                                                            </Icon>
                                                        </InputAdornment>
                                                    )
                                                }}
                                            />
                                        </GridItem>
                                        <GridItem xs={12} sm={12} md={3}>
                                            <CustomInput
                                                labelText="Phone 2"
                                                id="proposaltype"
                                                formControlProps={{
                                                    fullWidth: true
                                                }}
                                                inputProps={{
                                                    value: ToAddress.Phone2,
                                                    onChange: event => this.handleChangeTo(event, "phone2"),
                                                    endAdornment: (
                                                        <InputAdornment position="end" className={classes.inputAdornment}>
                                                            <Icon className={classes.User}>
                                                                call
                                                            </Icon>
                                                        </InputAdornment>
                                                    )
                                                }}
                                            />
                                        </GridItem>
                                        <GridItem xs={12} sm={12} md={3}>
                                            <CustomInput
                                                labelText="Email"
                                                id="registeremail"
                                                formControlProps={{
                                                    fullWidth: true
                                                }}
                                                inputProps={{
                                                    value: ToAddress.Email,
                                                    onChange: event => this.handleChangeTo(event, "email"),
                                                    endAdornment: (
                                                        <InputAdornment position="end" className={classes.inputAdornment}>
                                                            <Icon className={classes.inputAdornmentIcon}>
                                                                email
                                                            </Icon>
                                                        </InputAdornment>
                                                    )
                                                }}
                                            />
                                        </GridItem>
                                    </GridContainer>
                                </div>
                                <div className="shipment-pane" id="package">
                                    <GridContainer>
                                        <GridItem xs={12} sm={3} md={3}>
                                            <FormControl
                                                fullWidth
                                                className="input-select-outer"
                                            >
                                                <InputLabel
                                                    htmlFor="packagetype"
                                                    className={classes.selectLabel}
                                                >
                                                    Package Type <small>(required)</small>
                                                </InputLabel>
                                                <Select
                                                    MenuProps={{
                                                        className: classes.selectMenu
                                                    }}
                                                    classes={{
                                                        select: classes.select
                                                    }}
                                                    value={PackageType}
                                                    onChange={(event) => this.changePackage(event, "PackageType")}
                                                    inputProps={{
                                                        name: "packagetype",
                                                        id: "packagetype"
                                                    }}
                                                >
                                                    <MenuItem
                                                        value="Envelop"
                                                        classes={{
                                                            root: classes.selectMenuItem
                                                        }}
                                                    >
                                                        Document (Under 0.5Lbs)
                                                </MenuItem>
                                                    <MenuItem
                                                        value="Package"
                                                        classes={{
                                                            root: classes.selectMenuItem
                                                        }}
                                                    >
                                                        Package
                                                </MenuItem>
                                                </Select>
                                            </FormControl>
                                        </GridItem>
                                        <GridItem xs={12} sm={2} md={2}>
                                            <FormControl
                                                fullWidth
                                                className="input-select-outer"
                                            >
                                                <InputLabel
                                                    htmlFor="packagetype"
                                                    className={classes.selectLabel}
                                                >
                                                    No. of Packeges
                                            </InputLabel>
                                                <Select
                                                    MenuProps={{
                                                        className: classes.selectMenu
                                                    }}
                                                    classes={{
                                                        select: classes.select
                                                    }}
                                                    value={TotalPackages}
                                                    onChange={(event) => this.changePackage(event, "TotalPackage")}
                                                    inputProps={{
                                                        name: "packagetype",
                                                        id: "packagetype"
                                                    }}
                                                >
                                                    <MenuItem
                                                        value="1"
                                                        classes={{
                                                            root: classes.selectMenuItem
                                                        }}
                                                    >
                                                        1
                                                </MenuItem>
                                                    <MenuItem
                                                        value="2"
                                                        classes={{
                                                            root: classes.selectMenuItem
                                                        }}
                                                    >
                                                        2
                                                </MenuItem>
                                                    <MenuItem
                                                        value="3"
                                                        classes={{
                                                            root: classes.selectMenuItem
                                                        }}
                                                    >
                                                        3
                                                </MenuItem>
                                                </Select>
                                            </FormControl>
                                        </GridItem>
                                        <GridItem xs={12} sm={12} md={12}>
                                            <div className="package-table">
                                                <table>
                                                    <thead>
                                                        <tr>
                                                            <th>Number</th>
                                                            {this.state.ShipmentType.value === "Ocean" ?
                                                                <>
                                                                    <th>Sequence</th>
                                                                    <th>TV</th>
                                                                    <th>Stretch</th>
                                                                    <th>Repack</th>
                                                                    <th>Crating</th>
                                                                    <th>Package Content</th>
                                                                </>
                                                                :
                                                                null}
                                                            <th>Weight</th>
                                                            <th>Dim(L)</th>
                                                            <th>Dim(W)</th>
                                                            <th>Dim(H)</th>
                                                            <th>Chargeable Weight</th>
                                                            {this.state.ShipmentType.value !== "Ocean" ?
                                                                <th>Insurance</th>
                                                                :
                                                                null}
                                                            {this.state.ShipmentType.value === "Ocean" ?
                                                                <>
                                                                    <th>CFT</th>
                                                                    <th>Packed Type</th>
                                                                </>
                                                                :
                                                                null}
                                                            <th>Added by</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        {this.viewPackage()}
                                                    </tbody>
                                                </table>
                                            </div>
                                        </GridItem>
                                    </GridContainer>
                                </div>
                                <div className="shipment-pane" id="commercialinvoice">
                                    <GridContainer className="MuiGrid-justify-xs-center">
                                        <GridItem xs={12} sm={12} md={12}>
                                            <div className="package-table">
                                                <table>
                                                    <thead>
                                                        <tr>
                                                            <th>Package Number</th>
                                                            <th>Package Content</th>
                                                            <th>Quantity</th>
                                                            <th>Value Per Qty</th>
                                                            <th>Total Value</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        {this.viewCommercialInvoice()}
                                                    </tbody>
                                                </table>
                                            </div>
                                        </GridItem>
                                    </GridContainer>
                                </div>
                                <div className="shipment-pane" id="accounts">
                                    <GridContainer className="MuiGrid-justify-xs-center">
                                        <GridItem xs={12} sm={12} md={12}>
                                            <div className="policy-heading">
                                                <h3>Invoice</h3>
                                            </div>
                                            <div className="package-table">
                                                <table>
                                                    <thead>
                                                        <tr>
                                                            <th>Date</th>
                                                            <th>Service</th>
                                                            <th>Description</th>
                                                            <th>Qty</th>
                                                            <th>Cost</th>
                                                            <th>Total</th>
                                                            <th>Updated By</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        {this.viewInvoice()}
                                                        <tr>
                                                            <td className="text-align-right" colSpan="5"><b>Total Cost:</b></td>
                                                            <td className="text-align-right"><CustomInput /></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </GridItem>
                                    </GridContainer>

                                    <GridContainer className="MuiGrid-justify-xs-center">
                                        <GridItem xs={12} sm={12} md={12}>
                                            <div className="policy-heading">
                                                <h3>Payment Received</h3>
                                                <div className="ph-btn">
                                                </div>
                                            </div>
                                            <div className="package-table">
                                                <table>
                                                    <thead>
                                                        <tr>
                                                            <th>Date</th>
                                                            <th>Payment Type</th>
                                                            <th>Confirmation</th>
                                                            <th>TBD</th>
                                                            <th>Amount</th>
                                                            <th>Updated By</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        {this.paymentReceived()}
                                                        <tr>
                                                            <td className="text-align-right" colSpan="4"><b>Total Cost:</b></td>
                                                            <td className="text-align-right"><CustomInput /></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </GridItem>
                                    </GridContainer>

                                    <GridContainer className="MuiGrid-justify-xs-center">
                                        <GridItem xs={12} sm={12} md={12}>
                                            <div className="policy-heading">
                                                <h3>Payment Issued</h3>
                                                <div className="ph-btn">
                                                </div>
                                            </div>
                                            <div className="package-table">
                                                <table>
                                                    <thead>
                                                        <tr>
                                                            <th>Date</th>
                                                            <th>Vendor Name</th>
                                                            <th>Invoice Number</th>
                                                            <th>Date Paid</th>
                                                            <th>Paid Status</th>
                                                            <th>Amount</th>
                                                            <th>Updated By</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        {this.viewPaymentIssued()}
                                                        <tr>
                                                            <td className="text-align-right" colSpan="5"><b>Total Cost:</b></td>
                                                            <td className="text-align-right"><CustomInput /></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </GridItem>
                                    </GridContainer>

                                    <GridContainer className="MuiGrid-justify-xs-center">
                                        <GridItem xs={12} sm={12} md={12}>
                                            <div className="policy-heading">
                                                <h3>Payment Method</h3>
                                                <div className="ph-btn">
                                                </div>
                                            </div>
                                            <div className="package-table">
                                                <table>
                                                    <thead>
                                                        <tr>
                                                            <th>Type</th>
                                                            <th>Name</th>
                                                            <th>Number</th>
                                                            <th>Date Paid</th>
                                                            <th>Exp Date</th>
                                                            <th>Zipcode</th>
                                                            <th>Amount</th>
                                                            <th>Updated By</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        {this.viewPaymentMethod()}
                                                    </tbody>
                                                </table>
                                            </div>
                                        </GridItem>
                                    </GridContainer>
                                </div>
                                <div className="shipment-pane" id="tracking">
                                    <GridContainer className="MuiGrid-justify-xs-center">
                                        <GridItem xs={12} sm={12} md={12}>
                                            <div className="package-table">
                                                <table>
                                                    <thead>
                                                        <tr>

                                                            <th>Number</th>
                                                            <th>Date</th>
                                                            <th>Tracking Id</th>
                                                            <th>Carrier</th>
                                                            <th>Comments</th>
                                                            <th>Added by</th>
                                                            <th>Status</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        {/* <tr>
                                                    <td className="text-align-right">1</td>
                                                    <td>Clothes</td>
                                                    <td className="text-align-right">10</td>
                                                    <td className="text-align-right">$3.00</td>
                                                    <td className="text-align-right">$30.00</td>
                                                </tr> */}
                                                        {this.viewTrackingNumber()}
                                                    </tbody>
                                                </table>
                                            </div>
                                        </GridItem>
                                    </GridContainer>
                                </div>
                                <div className="shipment-pane" id="documentations">
                                    <GridContainer>
                                        <GridItem xs={12} sm={6} md={6}>
                                            <h3 className="margin-right-auto text-color-black">Documentation</h3>
                                        </GridItem>
                                    </GridContainer>
                                    <GridContainer justify="center">
                                        <GridItem xs={12} sm={12} md={12}>
                                            <ReactTable
                                                data={this.state.Attachments.filter(x => x.Status === "Active")}
                                                sortable={true}
                                                filterable={true}
                                                resizable={false}
                                                // defaultSorted={[
                                                //     {
                                                //       id: "CreatedOn",
                                                //       desc: true
                                                //     }
                                                //   ]}
                                                minRows={2}
                                                columns={columns}
                                                defaultPageSize={10}
                                                align="center"
                                                // className="-striped -highlight"
                                            />
                                        </GridItem>
                                    </GridContainer>
                                </div>
                            </div>
                        </Card>
                    </GridItem>
                </GridContainer>

                <GridContainer>
                    <GridItem xs={12} sm={12}>
                        <Card>
                            <CardHeader className="btn-right-outer" color="primary" icon>
                                <CardIcon color="primary">
                                    <FlightTakeoff />
                                </CardIcon>
                                <h4 className="margin-right-auto text-color-black">Notes</h4>
                            </CardHeader>
                            <div className="notes-table">
                                <div className="package-table">
                                    <table>
                                        <thead>
                                            <tr>
                                                <th>Date</th>
                                                <th>Comments</th>
                                                <th>Attachment</th>
                                                <th>Added By</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {this.viewNotes()}
                                        </tbody>
                                    </table>
                                    {/* <Button justify="center" onClick={this.handleAddNotesRow}>Add New Row</Button> */}
                                </div>
                            </div>

                        </Card>
                    </GridItem>
                </GridContainer>
                <Button justify="center" color="rose" onClick={() => this.handleSave()} >Save</Button>
            </div>
        );
    }
}
ShipmentCustom.propTypes = {
    classes: PropTypes.object
};

export default withStyles()(ShipmentCustom);